# Tools and Automation For Homework
I am lazy, so I code things to have them do work for me.
