﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Spammer
{
    /**
     * Author: notkohlrexo
     * 
     * ... no like seriously, do I look like someone who has fucking experience with token logging?
     */
    class DiscordWebhook : IDisposable
    {
        private WebClient dWebClient;
        private static NameValueCollection discordValues = new NameValueCollection();
        public string WebHook { get; set; }
        public string UserName { get; set; }
        public string ProfilePicture { get; set; }

        public DiscordWebhook()
        {

        }

        public void SendMessage(string msgSend)
        {
            dWebClient = new WebClient();
            discordValues.Add("username", UserName);
            discordValues.Add("avatar_url", ProfilePicture);
            discordValues.Add("content", msgSend);
            dWebClient.UploadValues(WebHook, discordValues);
            dWebClient.Dispose();
            discordValues.Remove("username");
            discordValues.Remove("avatar_url");
            discordValues.Remove("content");
        }

        public void Dispose()
        {
            dWebClient.Dispose();
        }
    }
}
