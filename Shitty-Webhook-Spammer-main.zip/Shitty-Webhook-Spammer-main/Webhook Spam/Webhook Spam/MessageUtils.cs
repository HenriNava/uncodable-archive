﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Spammer
{
    class MessageUtils
    {
        public static void ColoredMessage(ConsoleColor color, string text, bool newLine)
        {
            ConsoleColor oldColor = Console.ForegroundColor;
            Console.ForegroundColor = color;
            Console.Write(text + (newLine ? "\n" : ""));
            Console.ForegroundColor = oldColor;
        }
        public static void ColoredMessage(ConsoleColor color, string text)
        {
            ColoredMessage(color, text, true);
        }
    }
}
