﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Spammer
{
    class Spammer
    {
        static DiscordWebhook webhook = new DiscordWebhook();
        static string url = "", name = "Webhook Spammer by uncodable", pfp = "", msg = "@everyone";
        static int threads = 1, delay = 500, requests;
        static bool shutdown = true;

        static void Main()
        {
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            new Thread(() => {
                UpdateTitle();
            }).Start();

            Console.WriteLine("Simple Webhook Spammer by uncodable (uncodable#9463)\n" +
                              "Credits:\n" +
                              "notkohlrexo (icorex#4192) - For the actual Discord Webhook interaction\n" +
                              "Cystemzz (Cystemz#1337) - For being extraordinarily black (invisible at night)\n\n" +
                              "1) Set webhook URL (Current: " + url + ")\n" +
                              "2) Set webhook username (Current: " + name + ")\n" +
                              "3) Set webhook profile picture (Current: " + pfp + ")\n" +
                              "4) Set webhook spam message (Current: " + msg + ")\n" +
                              "5) Set thread count (Current: " + threads + ")\n" +
                              "6) Set request delay (Current: " + delay + ")\n" +
                              "7) Start spammer\n" +
                              "8) Stop spammer");
recovery:
            while (true)
            {
                try
                {
                    Console.Write("Select an option... ");
                    switch (int.Parse(Console.ReadLine()))
                    {
                        case 1:
                            {
                                Console.Write("Type in the target webhook URL... ");
                                string input = Console.ReadLine();
                                if (input == "")
                                {
                                    Console.WriteLine("Current URL: " + url);
                                    break;
                                }
                                url = input;
                                Console.WriteLine("Typed URL: " + url);
                                break;
                            }
                        case 2:
                            {
                                Console.Write("Type in the webhook username... ");
                                string input = Console.ReadLine();
                                if (input == "")
                                {
                                    Console.WriteLine("Current username: " + name);
                                    break;
                                }
                                name = input;
                                Console.WriteLine("Typed username: " + name);
                                break;
                            }
                        case 3:
                            {
                                Console.Write("Type in the webhook profile picture URL... ");
                                string input = Console.ReadLine();
                                if (input == "")
                                {
                                    Console.WriteLine("Current profile picture: " + pfp);
                                    break;
                                }
                                pfp = input;
                                Console.WriteLine("Typed profile picture: " + pfp);
                                break;
                            }
                        case 4:
                            {
                                Console.Write("Type in the webhook spam message... ");
                                string input = Console.ReadLine();
                                if (input == "")
                                {
                                    Console.WriteLine("Current message: " + msg);
                                    break;
                                }
                                msg = input;
                                Console.WriteLine("Typed message: " + msg);
                                break;
                            }
                        case 5:
                            {
                                Console.Write("Type in the thread count... ");
                                string input = Console.ReadLine();
                                int newCount;
                                bool check = int.TryParse(input, out newCount);
                                if (!check)
                                {
                                    Console.WriteLine("Way to go fuckass! You failed to type in an actual valid integer, slow in the head slow poke lookin ass...");
                                    break;
                                }
                                if (newCount == 0)
                                {
                                    Console.WriteLine("Current thread count: " + threads);
                                    break;
                                }
                                threads = newCount;
                                Console.WriteLine("Typed thread count: " + threads);
                                break;
                            }
                        case 6:
                            {
                                Console.Write("Type in the delay... ");
                                string input = Console.ReadLine();
                                int newDelay;
                                bool check = int.TryParse(input, out newDelay);
                                if (!check)
                                {
                                    Console.WriteLine("Way to go fuckass! You failed to type in an actual valid integer, slow in the head slow poke lookin ass...");
                                    break;
                                }
                                if (newDelay == 0)
                                {
                                    Console.WriteLine("Current delay count: " + delay);
                                    break;
                                }
                                delay = newDelay;
                                Console.WriteLine("Typed delay count: " + delay);
                                break;
                            }
                        case 7:
                            {
                                if (shutdown)
                                {
                                    shutdown = false;
                                    MessageUtils.ColoredMessage(ConsoleColor.Red, "Launching threads...");
                                    for (int i = 0; i < threads; i++)
                                    {
                                        Thread thread = new Thread(ThreadMe);
                                        thread.Start();
                                    }
                                    MessageUtils.ColoredMessage(ConsoleColor.Red, "All threads have started.");
                                }
                                else
                                {
                                    Console.WriteLine("All threads have already launched.");
                                }
                                break;
                            }
                        case 8:
                            {
                                if (!shutdown)
                                {
                                    shutdown = true;
                                    Console.WriteLine("Shutting down all threads...");
                                }
                                else
                                {
                                    Console.WriteLine("No threads are currently active.");
                                }
                                break;
                            }
                        default:
                            {
                                Console.WriteLine("You were so close, you selected an option that didn't even exist...");
                                break;
                            }
                    }
                }
                catch (Exception)
                {
                    Console.WriteLine("Nice one dumbass, you put in something that wasn't even an integer :facepalm:");
                    goto recovery;
                }
            }
        }

        static void UpdateTitle()
        {
            while (true)
            {
                Console.Title = "Webhook Spammer (" + requests + " Total Requests)";
                Thread.Sleep(3000);
            }
        }

        static void ThreadMe()
        {
            webhook.UserName = name;
            webhook.WebHook = url;
            webhook.ProfilePicture = pfp;
thread_recovery:
            try
            {
                while (true)
                {
                    webhook.SendMessage(msg);
                    if (shutdown)
                    {
                        return;
                    }
                    requests++;
                    Thread.Sleep(delay);
                }
            } catch (Exception)
            {
                goto thread_recovery;
            }
        }
    }
}
