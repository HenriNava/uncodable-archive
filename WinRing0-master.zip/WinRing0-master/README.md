# WinRing0
Windows Ring0 Access

###File Directory

>dll
* driver source

>drv
* driver normal interface

##Description
Allow user application to access ring0 level resource

* access cpu msr register
* read/write memory directly
* io pci device
* etc...





... but what if I told you, that this driver was vulnerable as all hell?

Allow me to introduce yet another project on my GitHub (that I probably will not finish for a long time due to time constraints)...

### Secure WinRing0
Securely access the kernel without leaving a wormhole in the process!

### Description
Allows a usermode application/program to access the kernel

Functions:
* Read and write to CPU model specific registers (MSRs)
* Read and write to physical memory directly
* PCI device input and output functionality
* ... and more!
