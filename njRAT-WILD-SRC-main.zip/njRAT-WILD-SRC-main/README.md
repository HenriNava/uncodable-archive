# njRAT (In Wild) Source Code
Looking through URLHaus' vast database, I found a sample of the nj Remote Administration Tool. Since the RAT was unobfuscated, I decided to turn it into source code. You can easily make this compilable, too.
