using System;

namespace DrHazemBasharBachir
{
	// Token: 0x02000005 RID: 5
	public class DrHazem
	{
		// Token: 0x0600000A RID: 10 RVA: 0x000020D8 File Offset: 0x000002D8
		[STAThread]
		public static void main()
		{
			OK.ko();
		}
	}
}
