using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace ADODB
{
	// Token: 0x02000025 RID: 37
	[CompilerGenerated]
	[Guid("00000506-0000-0010-8000-00AA006D2EA4")]
	[TypeIdentifier]
	[ComImport]
	public interface Fields15 : _Collection
	{
		// Token: 0x060002B5 RID: 693
		void _VtblGap1_3();

		// Token: 0x1700010F RID: 271
		[DispId(0)]
		Field this[[MarshalAs(UnmanagedType.Struct)] [In] object Index]
		{
			[DispId(0)]
			[MethodImpl(MethodImplOptions.InternalCall)]
			[return: MarshalAs(UnmanagedType.Interface)]
			get;
		}
	}
}
