using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace ADODB
{
	// Token: 0x02000021 RID: 33
	[CompilerGenerated]
	[Guid("00000530-0000-0010-8000-00AA006D2EA4")]
	[TypeIdentifier("b691e011-1797-432e-907a-4d8c69339129", "ADODB.EventStatusEnum")]
	public enum EventStatusEnum
	{
		// Token: 0x0400013F RID: 319
		adStatusOK = 1,
		// Token: 0x04000140 RID: 320
		adStatusErrorsOccurred,
		// Token: 0x04000141 RID: 321
		adStatusCantDeny,
		// Token: 0x04000142 RID: 322
		adStatusCancel,
		// Token: 0x04000143 RID: 323
		adStatusUnwantedEvent
	}
}
