using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace ADODB
{
	// Token: 0x0200001F RID: 31
	[CompilerGenerated]
	[Guid("0000051B-0000-0010-8000-00AA006D2EA4")]
	[TypeIdentifier("b691e011-1797-432e-907a-4d8c69339129", "ADODB.CursorTypeEnum")]
	public enum CursorTypeEnum
	{
		// Token: 0x04000139 RID: 313
		adOpenUnspecified = -1,
		// Token: 0x0400013A RID: 314
		adOpenForwardOnly,
		// Token: 0x0400013B RID: 315
		adOpenKeyset,
		// Token: 0x0400013C RID: 316
		adOpenDynamic,
		// Token: 0x0400013D RID: 317
		adOpenStatic
	}
}
