using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace ADODB
{
	// Token: 0x0200001B RID: 27
	[CompilerGenerated]
	[Guid("00000550-0000-0010-8000-00AA006D2EA4")]
	[CoClass(typeof(object))]
	[TypeIdentifier]
	[ComImport]
	public interface Connection : _Connection, ConnectionEvents_Event
	{
	}
}
