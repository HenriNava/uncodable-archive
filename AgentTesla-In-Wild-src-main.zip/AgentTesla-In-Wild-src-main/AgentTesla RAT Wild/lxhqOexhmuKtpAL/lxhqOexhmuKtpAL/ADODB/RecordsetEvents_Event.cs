using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace ADODB
{
	// Token: 0x0200002D RID: 45
	[CompilerGenerated]
	[ComEventInterface(typeof(RecordsetEvents), typeof(RecordsetEvents))]
	[TypeIdentifier("b691e011-1797-432e-907a-4d8c69339129", "ADODB.RecordsetEvents_Event")]
	[ComImport]
	public interface RecordsetEvents_Event
	{
	}
}
