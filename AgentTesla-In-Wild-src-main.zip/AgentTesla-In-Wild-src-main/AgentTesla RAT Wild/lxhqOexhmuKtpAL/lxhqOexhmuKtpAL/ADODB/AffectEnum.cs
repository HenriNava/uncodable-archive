using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace ADODB
{
	// Token: 0x0200001A RID: 26
	[CompilerGenerated]
	[Guid("00000543-0000-0010-8000-00AA006D2EA4")]
	[TypeIdentifier("b691e011-1797-432e-907a-4d8c69339129", "ADODB.AffectEnum")]
	public enum AffectEnum
	{
		// Token: 0x04000134 RID: 308
		adAffectCurrent = 1,
		// Token: 0x04000135 RID: 309
		adAffectGroup,
		// Token: 0x04000136 RID: 310
		adAffectAll,
		// Token: 0x04000137 RID: 311
		adAffectAllChapters
	}
}
