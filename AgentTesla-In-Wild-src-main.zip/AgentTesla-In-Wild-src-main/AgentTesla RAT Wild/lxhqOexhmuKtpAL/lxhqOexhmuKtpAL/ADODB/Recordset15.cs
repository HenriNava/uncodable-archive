using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace ADODB
{
	 Token 0x02000029 RID 41
	[CompilerGenerated]
	[DefaultMember(Fields)]
	[Guid(0000050E-0000-0010-8000-00AA006D2EA4)]
	[TypeIdentifier]
	[ComImport]
	public interface Recordset15  _ADO
	{
		 Token 0x060002B9 RID 697
		void _VtblGap1_14();

		 Token 0x17000111 RID 273
		 (get) Token 0x060002BA RID 698
		[DispId(0)]
		[IndexerName(Fields)]
		Fields Fields { [DispId(0)] [MethodImpl(MethodImplOptions.InternalCall)] [return MarshalAs(UnmanagedType.Interface)] get; }
	}
}
