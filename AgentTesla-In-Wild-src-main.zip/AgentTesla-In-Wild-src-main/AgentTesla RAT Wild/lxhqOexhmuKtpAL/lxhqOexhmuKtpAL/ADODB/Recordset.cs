using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace ADODB
{
	// Token: 0x02000028 RID: 40
	[CompilerGenerated]
	[Guid("00000556-0000-0010-8000-00AA006D2EA4")]
	[CoClass(typeof(object))]
	[TypeIdentifier]
	[ComImport]
	public interface Recordset : _Recordset, RecordsetEvents_Event
	{
	}
}
