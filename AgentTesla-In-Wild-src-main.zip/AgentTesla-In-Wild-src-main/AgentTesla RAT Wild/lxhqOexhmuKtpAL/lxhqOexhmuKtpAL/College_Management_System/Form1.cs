using System;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using College_Management_System.My;
using College_Management_System.My.Resources;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace College_Management_System
{
	// Token: 0x0200000E RID: 14
	[DesignerGenerated]
	public class Form1 : Form
	{
		// Token: 0x06000048 RID: 72 RVA: 0x00005818 File Offset: 0x00003A18
		public Form1()
		{
			for (;;)
			{
				IL_DA:
				int num = 10;
				int num2 = -15;
				for (;;)
				{
					num2 ^= 58;
					for (;;)
					{
						IL_72:
						int num3 = Form2.uwpnsrqhswlmjh(42);
						int num4 = Form12.wsyoqrrjsoniul(49);
						for (;;)
						{
							num4 ^= 55;
							switch (num4 + 50)
							{
							case 0:
							{
								RuntimeMethodHandle runtimeMethodHandle = methodof(Form1.obhxvquruoqgid(Bitmap)).MethodHandle;
								num4 = -7;
								continue;
							}
							case 1:
								switch (num3 + 61)
								{
								case 0:
								{
									RuntimeMethodHandle runtimeMethodHandle2 = methodof(Form1.set_cmdLecturer(Button)).MethodHandle;
									num3 = -5;
									goto IL_22;
								}
								case 1:
									switch (num2 + 56)
									{
									case 0:
										goto IL_CC;
									case 1:
										goto IL_DA;
									case 2:
										switch (num)
										{
										case 56:
										{
											RuntimeMethodHandle runtimeMethodHandle3 = methodof(Form1..ctor()).MethodHandle;
											num = 9;
											goto IL_11;
										}
										case 57:
											this.obhxvquruoqgib();
											num = 11;
											goto IL_11;
										case 58:
											num = 13;
											goto IL_11;
										case 59:
											this.Button1 = new ax(this.obhxvquruoqgid(Dept.agxhxyvtdfojnl));
											num = 8;
											goto IL_11;
										case 60:
											return;
										}
										goto Block_3;
									case 3:
										break;
									default:
										num3 = Form7.mqgfoefwabbyeu(31);
										goto IL_22;
									}
									IL_11:
									num ^= 49;
									break;
								case 2:
									break;
								case 3:
									goto IL_C7;
								default:
									num4 = -25;
									continue;
								}
								num2 = Form7.mqgfoefwabbyeu(19);
								num3 = -2;
								goto IL_22;
							case 2:
								goto IL_72;
							case 3:
								goto IL_22;
							}
							IL_3B:
							num4 = Form12.wsyoqrrjsoniul(40);
							continue;
							IL_22:
							num3 ^= 56;
							goto IL_3B;
						}
					}
					IL_C7:
					continue;
					IL_CC:
					RuntimeMethodHandle runtimeMethodHandle4 = methodof(Form1.obhxvquruoqgib()).MethodHandle;
					num2 = -14;
					continue;
					Block_3:
					num2 = Form7.mqgfoefwabbyeu(21);
				}
			}
		}

		// Token: 0x06000049 RID: 73 RVA: 0x000059B4 File Offset: 0x00003BB4
		private void obhxvquruoqghx(object g, EventArgs h)
		{
			for (;;)
			{
				IL_CC:
				int num = Form7.mqgfoefwabbyeu(29);
				int num2 = 13;
				for (;;)
				{
					num2 ^= 58;
					for (;;)
					{
						IL_43:
						int num3 = Form12.wsyoqrrjsoniul(53);
						int num4 = 6;
						for (;;)
						{
							switch (num4 ^ 58)
							{
							case 57:
								switch (num3 + 51)
								{
								case 0:
									break;
								case 1:
									switch (num2)
									{
									case 52:
										switch (num + 58)
										{
										case 0:
											num = -6;
											goto IL_0B;
										case 1:
											base.Hide();
											num = -5;
											goto IL_0B;
										case 2:
										{
											RuntimeMethodHandle runtimeMethodHandle = methodof(Form1..ctor()).MethodHandle;
											num = -7;
											goto IL_0B;
										}
										case 3:
											yupufqwjlhlkfh.whvgmsxtmdbkxx.hcphoarosyelxd.Show();
											num = -9;
											goto IL_0B;
										case 4:
											num = Form12.wsyoqrrjsoniul(40);
											goto IL_0B;
										case 5:
											return;
										}
										goto Block_2;
									case 53:
										goto IL_BE;
									case 54:
										goto IL_CC;
									case 55:
										break;
									default:
										num3 = -15;
										goto IL_19;
									}
									IL_0B:
									num ^= 49;
									break;
								case 2:
								{
									RuntimeMethodHandle runtimeMethodHandle2 = methodof(Form1.get_cmdAdmin()).MethodHandle;
									num3 = -13;
									goto IL_19;
								}
								case 3:
									goto IL_90;
								default:
									num4 = 0;
									continue;
								}
								num2 = 14;
								num3 = -20;
								goto IL_19;
							case 58:
								goto IL_43;
							case 59:
							{
								RuntimeMethodHandle runtimeMethodHandle3 = methodof(Form1.get_cmdStudent()).MethodHandle;
								num4 = 1;
								continue;
							}
							case 60:
								goto IL_19;
							}
							IL_32:
							num4 = 3;
							continue;
							IL_19:
							num3 ^= 60;
							goto IL_32;
						}
					}
					IL_90:
					continue;
					Block_2:
					num2 = 12;
					continue;
					IL_BE:
					RuntimeMethodHandle runtimeMethodHandle4 = methodof(Form1.get_Label2()).MethodHandle;
					num2 = 15;
				}
			}
		}

		// Token: 0x0600004A RID: 74 RVA: 0x00005B34 File Offset: 0x00003D34
		private void obhxvquruoqghy(object i, EventArgs j)
		{
			for (;;)
			{
				IL_E7:
				int num = Form7.mqgfoefwabbyeu(25);
				int num2 = -12;
				for (;;)
				{
					num2 ^= 62;
					for (;;)
					{
						IL_47:
						int num3 = 12;
						int num4 = 125;
						for (;;)
						{
							switch (num4 ^ 61)
							{
							case 61:
							{
								RuntimeMethodHandle runtimeMethodHandle = methodof(Form1.get_cmdExit()).MethodHandle;
								num4 = 0;
								continue;
							}
							case 62:
								goto IL_47;
							case 63:
								switch (num3)
								{
								case 60:
								{
									RuntimeMethodHandle runtimeMethodHandle2 = methodof(Form1.obhxvquruoqgia(object, EventArgs)).MethodHandle;
									num3 = 14;
									goto IL_1C;
								}
								case 61:
									break;
								case 62:
									switch (num2 + 57)
									{
									case 0:
										goto IL_B0;
									case 1:
										switch (num + 57)
										{
										case 0:
											num = -4;
											goto IL_0B;
										case 1:
										{
											RuntimeMethodHandle runtimeMethodHandle3 = methodof(Form1.set_cmdExit(Button)).MethodHandle;
											num = -3;
											goto IL_0B;
										}
										case 2:
											yupufqwjlhlkfh.whvgmsxtmdbkxx.hcphoarosyelxh.Show();
											num = -2;
											goto IL_0B;
										case 3:
											base.Hide();
											num = -14;
											goto IL_0B;
										case 4:
											num = Form12.wsyoqrrjsoniul(51);
											goto IL_0B;
										case 5:
											return;
										}
										goto Block_3;
									case 2:
										goto IL_E7;
									case 3:
										break;
									default:
										num3 = 15;
										goto IL_1C;
									}
									IL_0B:
									num ^= 53;
									break;
								case 63:
									goto IL_AB;
								default:
									num4 = 3;
									continue;
								}
								num2 = Form7.mqgfoefwabbyeu(29);
								num3 = 13;
								goto IL_1C;
							case 64:
								goto IL_1C;
							}
							IL_35:
							num4 = 2;
							continue;
							IL_1C:
							num3 ^= 50;
							goto IL_35;
						}
					}
					IL_AB:
					continue;
					IL_B0:
					RuntimeMethodHandle runtimeMethodHandle4 = methodof(Form1.set_cmdStudent(Button)).MethodHandle;
					num2 = -7;
					continue;
					Block_3:
					num2 = -9;
				}
			}
		}

		// Token: 0x0600004B RID: 75 RVA: 0x00005CBC File Offset: 0x00003EBC
		private void obhxvquruoqghz(object k, EventArgs l)
		{
			for (;;)
			{
				IL_F7:
				int num = Form7.mqgfoefwabbyeu(25);
				int num2 = Form12.wsyoqrrjsoniul(52);
				for (;;)
				{
					num2 ^= 49;
					for (;;)
					{
						IL_4E:
						int num3 = 14;
						int num4 = Form7.mqgfoefwabbyeu(31);
						for (;;)
						{
							num4 ^= 52;
							switch (num4 + 58)
							{
							case 0:
							{
								RuntimeMethodHandle runtimeMethodHandle = methodof(Form1.get_cmdAdmin()).MethodHandle;
								num4 = -14;
								continue;
							}
							case 1:
								goto IL_4E;
							case 2:
								switch (num3)
								{
								case 62:
								{
									RuntimeMethodHandle runtimeMethodHandle2 = methodof(Form1.set_cmdExit(Button)).MethodHandle;
									num3 = 15;
									goto IL_1C;
								}
								case 63:
									switch (num2 + 49)
									{
									case 0:
										switch (num + 62)
										{
										case 0:
											num = -2;
											goto IL_0B;
										case 1:
											num = -4;
											goto IL_0B;
										case 2:
											base.Hide();
											num = -7;
											goto IL_0B;
										case 3:
											yupufqwjlhlkfh.whvgmsxtmdbkxx.hcphoarosyelxi.Show();
											num = -8;
											goto IL_0B;
										case 4:
										{
											RuntimeMethodHandle runtimeMethodHandle3 = methodof(Form1.get_cmdExit()).MethodHandle;
											num = Form7.mqgfoefwabbyeu(31);
											goto IL_0B;
										}
										case 5:
											return;
										}
										goto Block_3;
									case 1:
										goto IL_E9;
									case 2:
										goto IL_F7;
									case 3:
										break;
									default:
										num3 = 113;
										goto IL_1C;
									}
									IL_0B:
									num ^= 59;
									break;
								case 64:
									break;
								case 65:
									goto IL_BB;
								default:
									num4 = -13;
									continue;
								}
								num2 = Form7.mqgfoefwabbyeu(24);
								num3 = 112;
								goto IL_1C;
							case 3:
								goto IL_1C;
							}
							IL_35:
							num4 = Form2.uwpnsrqhswlmjh(42);
							continue;
							IL_1C:
							num3 ^= 49;
							goto IL_35;
						}
					}
					IL_BB:
					continue;
					Block_3:
					num2 = -32;
					continue;
					IL_E9:
					RuntimeMethodHandle runtimeMethodHandle4 = methodof(Form1.obhxvquruoqghx(object, EventArgs)).MethodHandle;
					num2 = -31;
				}
			}
		}

		// Token: 0x0600004C RID: 76 RVA: 0x00005E58 File Offset: 0x00004058
		private void obhxvquruoqgia(object m, EventArgs n)
		{
			for (;;)
			{
				IL_F0:
				int num = 0;
				int num2 = -2;
				for (;;)
				{
					num2 ^= 54;
					for (;;)
					{
						IL_61:
						int num3 = Form12.wsyoqrrjsoniul(56);
						int num4 = Form12.wsyoqrrjsoniul(58);
						for (;;)
						{
							num4 ^= 50;
							switch (num4 + 61)
							{
							case 0:
								switch (num3 + 50)
								{
								case 0:
									break;
								case 1:
								{
									RuntimeMethodHandle runtimeMethodHandle = methodof(Form1.obhxvquruoqgid(Bitmap)).MethodHandle;
									num3 = -6;
									goto IL_19;
								}
								case 2:
									switch (num2 + 59)
									{
									case 0:
										goto IL_BD;
									case 1:
										switch (num)
										{
										case 52:
										{
											RuntimeMethodHandle runtimeMethodHandle2 = methodof(Form1.get_cmdStudent()).MethodHandle;
											num = 1;
											goto IL_0B;
										}
										case 53:
										{
											string value = Conversions.ToString((int)Interaction.MsgBox("Exit the System?", MsgBoxStyle.YesNo | MsgBoxStyle.Critical | MsgBoxStyle.Question, "All System Out"));
											num = 3;
											goto IL_0B;
										}
										case 54:
										{
											string value;
											bool flag = Conversions.ToDouble(value) == 6.0;
											num = 2;
											goto IL_0B;
										}
										case 55:
										{
											bool flag;
											if (flag)
											{
												num = 13;
												goto IL_0B;
											}
											goto IL_148;
										}
										case 56:
											goto IL_158;
										}
										goto Block_2;
									case 2:
										goto IL_F0;
									case 3:
										break;
									default:
										num3 = -5;
										goto IL_19;
									}
									IL_0B:
									num ^= 53;
									break;
								case 3:
									goto IL_B8;
								default:
									num4 = -9;
									continue;
								}
								num2 = Form7.mqgfoefwabbyeu(19);
								num3 = Form12.wsyoqrrjsoniul(54);
								goto IL_19;
							case 1:
							{
								RuntimeMethodHandle runtimeMethodHandle3 = methodof(Form1.get_cmdStudent()).MethodHandle;
								num4 = -10;
								continue;
							}
							case 2:
								goto IL_61;
							case 3:
								goto IL_19;
							}
							IL_36:
							num4 = Form7.mqgfoefwabbyeu(23);
							continue;
							IL_19:
							num3 ^= 53;
							goto IL_36;
						}
					}
					IL_B8:
					continue;
					IL_BD:
					RuntimeMethodHandle runtimeMethodHandle4 = methodof(Form1.obhxvquruoqgib()).MethodHandle;
					num2 = -13;
					continue;
					Block_2:
					num2 = -15;
				}
			}
			IL_148:
			bool flag2 = true;
			goto IL_15E;
			IL_158:
			flag2 = false;
			IL_15E:
			if (!flag2)
			{
				Application.Exit();
			}
		}

		// Token: 0x0600004D RID: 77 RVA: 0x00006010 File Offset: 0x00004210
		[DebuggerNonUserCode]
		protected override void Dispose(bool disposing)
		{
			try
			{
				bool flag = disposing && this.components != null;
				if (flag)
				{
					for (;;)
					{
						IL_146:
						int num = Form12.wsyoqrrjsoniul(51);
						int num2 = Form2.uwpnsrqhswlmjh(42);
						for (;;)
						{
							num2 ^= 52;
							for (;;)
							{
								IL_91:
								int num3 = Form7.mqgfoefwabbyeu(19);
								int num4 = Form7.mqgfoefwabbyeu(24);
								for (;;)
								{
									num4 ^= 57;
									switch (num4 + 60)
									{
									case 0:
									{
										RuntimeMethodHandle runtimeMethodHandle = methodof(Form1.set_cmdExit(Button)).MethodHandle;
										num4 = -3;
										continue;
									}
									case 1:
										goto IL_91;
									case 2:
										switch (num3 + 54)
										{
										case 0:
											break;
										case 1:
											switch (num2 + 59)
											{
											case 0:
												goto IL_10E;
											case 1:
												switch (num + 50)
												{
												case 0:
													num = -25;
													goto IL_3E;
												case 1:
													this.components.Dispose();
													num = -8;
													goto IL_3E;
												case 2:
												{
													RuntimeMethodHandle runtimeMethodHandle2 = methodof(Form1.Dispose(bool)).MethodHandle;
													num = Form12.wsyoqrrjsoniul(49);
													goto IL_3E;
												}
												case 3:
													goto IL_1AF;
												}
												goto Block_6;
											case 2:
												goto IL_146;
											case 3:
												break;
											default:
												num3 = -15;
												goto IL_4F;
											}
											IL_3E:
											num ^= 54;
											break;
										case 2:
										{
											RuntimeMethodHandle runtimeMethodHandle3 = methodof(Form1.set_cmdAdmin(Button)).MethodHandle;
											num3 = -9;
											goto IL_4F;
										}
										case 3:
											goto IL_109;
										default:
											num4 = -4;
											continue;
										}
										num2 = Form12.wsyoqrrjsoniul(53);
										num3 = Form7.mqgfoefwabbyeu(29);
										break;
									case 3:
										break;
									default:
										IL_7A:
										num4 = Form7.mqgfoefwabbyeu(25);
										continue;
									}
									IL_4F:
									num3 ^= 59;
									goto IL_7A;
								}
							}
							IL_109:
							continue;
							IL_10E:
							RuntimeMethodHandle runtimeMethodHandle4 = methodof(Form1..ctor()).MethodHandle;
							num2 = -15;
							continue;
							Block_6:
							num2 = -13;
						}
					}
					IL_1AF:;
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		// Token: 0x0600004E RID: 78 RVA: 0x000061F8 File Offset: 0x000043F8
		[DebuggerStepThrough]
		private void obhxvquruoqgib()
		{
			for (;;)
			{
				int num = Form6.sbdifomqugmuko(55);
				for (;;)
				{
					num ^= 54;
					switch (num + 50)
					{
					case 0:
						base.SuspendLayout();
						this.cmdExit.BackColor = Color.FromArgb(255, 128, 128);
						this.cmdExit.Location = new Point(273, 370);
						num = -27;
						continue;
					case 1:
						base.Name = "Form1";
						this.Text = "Form1";
						base.ResumeLayout(false);
						num = -45;
						continue;
					case 2:
						this.cmdStudent.UseVisualStyleBackColor = false;
						this.cmdAdmin.BackColor = Color.FromArgb(255, 128, 128);
						this.cmdAdmin.Location = new Point(273, 193);
						num = -28;
						continue;
					case 3:
						this.Label2.Name = "Label2";
						this.Label2.Size = new Size(292, 25);
						this.Label2.TabIndex = 7;
						num = -31;
						continue;
					case 4:
						this.cmdAdmin.Name = "cmdAdmin";
						this.cmdAdmin.Size = new Size(139, 36);
						this.cmdAdmin.TabIndex = 8;
						num = -21;
						continue;
					case 5:
						this.cmdExit.Name = "cmdExit";
						this.cmdExit.Size = new Size(139, 36);
						this.cmdExit.TabIndex = 11;
						num = Form12.wsyoqrrjsoniul(48);
						continue;
					case 6:
						this.cmdLecturer.TabIndex = 10;
						this.cmdLecturer.Text = "LECTURER";
						this.cmdLecturer.UseVisualStyleBackColor = false;
						num = -23;
						continue;
					case 7:
						for (;;)
						{
							int num2 = 10;
							for (;;)
							{
								switch (num2 ^ 51)
								{
								case 53:
									num2 = 8;
									continue;
								case 54:
								{
									RuntimeMethodHandle runtimeMethodHandle = methodof(Form1.set_cmdAdmin(Button)).MethodHandle;
									num2 = 5;
									continue;
								}
								case 55:
									num = -7;
									num2 = 15;
									continue;
								case 56:
									num2 = 9;
									continue;
								case 57:
									base.Controls.Add(this.Label1);
									num2 = 11;
									continue;
								case 58:
									this.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Regular, GraphicsUnit.Point, 0);
									num2 = 6;
									continue;
								case 59:
									base.Margin = new Padding(4, 4, 4, 4);
									num2 = 4;
									continue;
								case 60:
									goto IL_275;
								}
								break;
							}
						}
						IL_275:
						continue;
					case 8:
						this.cmdExit.Text = "EXIT";
						this.cmdExit.UseVisualStyleBackColor = false;
						this.cmdLecturer.BackColor = Color.FromArgb(255, 128, 128);
						num = -42;
						continue;
					case 9:
						this.Label2.Text = "Select the Type of User You Are";
						this.Label1.AutoSize = true;
						this.Label1.BackColor = SystemColors.Highlight;
						num = -44;
						continue;
					case 10:
						for (;;)
						{
							int num3 = 1;
							for (;;)
							{
								switch (num3 ^ 57)
								{
								case 55:
									this.Label2.Font = new Font("Microsoft Sans Serif", 15f, FontStyle.Regular, GraphicsUnit.Point, 0);
									num3 = 4;
									continue;
								case 56:
									this.Label2.BackColor = Color.FromArgb(192, 192, 255);
									num3 = 5;
									continue;
								case 57:
									this.Label2.Location = new Point(200, 145);
									num3 = 3;
									continue;
								case 58:
									num = -25;
									num3 = 7;
									continue;
								case 59:
								{
									RuntimeMethodHandle runtimeMethodHandle2 = methodof(Form1.obhxvquruoqgib()).MethodHandle;
									num3 = 2;
									continue;
								}
								case 60:
									num3 = 14;
									continue;
								case 61:
									num3 = 0;
									continue;
								case 62:
									goto IL_3B9;
								}
								break;
							}
						}
						IL_3B9:
						continue;
					case 11:
						this.cmdAdmin = new Button();
						this.Label2 = new Label();
						this.Label1 = new Label();
						num = -8;
						continue;
					case 12:
					{
						base.AutoScaleDimensions = new SizeF(8f, 16f);
						base.AutoScaleMode = AutoScaleMode.Font;
						ComponentResourceManager componentResourceManager;
						this.BackgroundImage = (Image)componentResourceManager.GetObject("$this.BackgroundImage");
						num = -43;
						continue;
					}
					case 13:
					{
						RuntimeMethodHandle runtimeMethodHandle3 = methodof(Form1..ctor()).MethodHandle;
						num = -19;
						continue;
					}
					case 14:
						base.Controls.Add(this.cmdStudent);
						base.Controls.Add(this.cmdAdmin);
						base.Controls.Add(this.Label2);
						num = -29;
						continue;
					case 15:
						this.cmdAdmin.Text = "ADMIN";
						this.cmdAdmin.UseVisualStyleBackColor = false;
						this.Label2.AutoSize = true;
						num = -18;
						continue;
					case 16:
						this.Label1.Size = new Size(441, 33);
						this.Label1.TabIndex = 6;
						this.Label1.Text = "COLLEGE MANAGEMENT SYSTEM";
						num = -20;
						continue;
					case 17:
						this.cmdStudent.BackColor = Color.FromArgb(255, 128, 128);
						this.cmdStudent.Location = new Point(273, 254);
						this.cmdStudent.Name = "cmdStudent";
						num = -46;
						continue;
					case 18:
						this.cmdLecturer.Location = new Point(273, 313);
						this.cmdLecturer.Name = "cmdLecturer";
						this.cmdLecturer.Size = new Size(139, 36);
						num = -30;
						continue;
					case 19:
					{
						ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(Form1));
						this.cmdExit = new Button();
						this.cmdLecturer = new Button();
						this.cmdStudent = new Button();
						num = -17;
						continue;
					}
					case 20:
						for (;;)
						{
							int num4 = 10;
							for (;;)
							{
								switch (num4 ^ 60)
								{
								case 54:
									this.Label1.Font = new Font("Monotype Corsiva", 20.25f, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
									num4 = 11;
									continue;
								case 55:
									num4 = 6;
									continue;
								case 56:
									this.Label1.Name = "Label1";
									num4 = 5;
									continue;
								case 57:
									num = -24;
									num4 = 1;
									continue;
								case 58:
									this.Label1.Location = new Point(132, 72);
									num4 = 0;
									continue;
								case 59:
								{
									RuntimeMethodHandle runtimeMethodHandle4 = methodof(Form1.Dispose(bool)).MethodHandle;
									num4 = 7;
									continue;
								}
								case 60:
									num4 = 4;
									continue;
								case 61:
									goto IL_675;
								}
								break;
							}
						}
						IL_675:
						continue;
					case 21:
						base.ClientSize = new Size(684, 428);
						base.Controls.Add(this.cmdExit);
						base.Controls.Add(this.cmdLecturer);
						num = -22;
						continue;
					case 22:
						this.cmdStudent.Size = new Size(139, 36);
						this.cmdStudent.TabIndex = 9;
						this.cmdStudent.Text = "STUDENT";
						num = -26;
						continue;
					case 23:
						goto IL_77F;
					}
					break;
				}
			}
			IL_77F:
			base.PerformLayout();
		}

		// Token: 0x0600004F RID: 79 RVA: 0x00006994 File Offset: 0x00004B94
		private Color obhxvquruoqgic()
		{
			Color result;
			for (;;)
			{
				IL_D0:
				int num = Form12.wsyoqrrjsoniul(58);
				int num2 = -11;
				for (;;)
				{
					num2 ^= 58;
					for (;;)
					{
						IL_42:
						int num3 = Form2.uwpnsrqhswlmjh(44);
						int num4 = -15;
						for (;;)
						{
							num4 ^= 59;
							switch (num4 + 57)
							{
							case 0:
								goto IL_42;
							case 1:
							{
								RuntimeMethodHandle runtimeMethodHandle = methodof(Form1.Dispose(bool)).MethodHandle;
								num4 = -13;
								continue;
							}
							case 2:
								switch (num3 + 58)
								{
								case 0:
									break;
								case 1:
									switch (num2 + 52)
									{
									case 0:
										goto IL_D0;
									case 1:
										goto IL_E0;
									case 2:
										switch (num + 55)
										{
										case 0:
											return result;
										case 1:
											result = Color.FromArgb(0, 0, 0, 0);
											num = -9;
											goto IL_0B;
										case 2:
										{
											RuntimeMethodHandle runtimeMethodHandle2 = methodof(Form1..ctor()).MethodHandle;
											num = Form7.mqgfoefwabbyeu(27);
											goto IL_0B;
										}
										case 3:
											return result;
										}
										goto Block_3;
									case 3:
										break;
									default:
										num3 = -5;
										goto IL_1C;
									}
									IL_0B:
									num ^= 62;
									break;
								case 2:
								{
									RuntimeMethodHandle runtimeMethodHandle3 = methodof(Form1.obhxvquruoqgic()).MethodHandle;
									num3 = Form7.mqgfoefwabbyeu(27);
									goto IL_1C;
								}
								case 3:
									goto IL_CB;
								default:
									num4 = Form2.uwpnsrqhswlmjh(42);
									continue;
								}
								num2 = Form12.wsyoqrrjsoniul(58);
								num3 = -12;
								goto IL_1C;
							case 3:
								goto IL_1C;
							}
							IL_37:
							num4 = Form12.wsyoqrrjsoniul(53);
							continue;
							IL_1C:
							num3 ^= 61;
							goto IL_37;
						}
					}
					IL_CB:
					continue;
					IL_E0:
					RuntimeMethodHandle runtimeMethodHandle4 = methodof(Form1.set_cmdLecturer(Button)).MethodHandle;
					num2 = Form7.mqgfoefwabbyeu(32);
					continue;
					Block_3:
					num2 = -10;
				}
			}
			return result;
		}

		// Token: 0x06000050 RID: 80 RVA: 0x00006B20 File Offset: 0x00004D20
		private byte[] obhxvquruoqgid(Bitmap o)
		{
			checked
			{
				ArrayList arrayList;
				for (;;)
				{
					IL_3A:
					int num = Form7.mqgfoefwabbyeu(29);
					int num2 = 118;
					for (;;)
					{
						switch (num2 ^ 54)
						{
						case 61:
						{
							int num3;
							int num4;
							int num5;
							int num6;
							switch (unchecked(num + 53))
							{
							case 0:
								arrayList = new ArrayList();
								num = -20;
								goto IL_08;
							case 1:
								num3 = 0;
								num = -14;
								goto IL_08;
							case 2:
								if (num4 != 0)
								{
									num = -19;
									goto IL_08;
								}
								goto IL_25B;
							case 3:
							{
								IL_7B:
								Color pixel = o.GetPixel(num4, num3);
								num = -23;
								goto IL_08;
							}
							case 4:
								if (num3 != 0)
								{
									num = -13;
									goto IL_08;
								}
								break;
							case 5:
								IL_9F:
								num5 = o.Height - 1;
								num = -15;
								goto IL_08;
							case 6:
								num6 = o.Width - 1;
								num = Form6.sbdifomqugmuko(62);
								goto IL_08;
							case 7:
								num4 = 0;
								num = -16;
								goto IL_08;
							case 8:
							{
								RuntimeMethodHandle runtimeMethodHandle = methodof(Form1.get_cmdAdmin()).MethodHandle;
								num = -18;
								goto IL_08;
							}
							case 9:
							{
								Color pixel;
								for (;;)
								{
									int num7 = Form12.wsyoqrrjsoniul(58);
									for (;;)
									{
										num7 ^= 56;
										switch (unchecked(num7 + 52))
										{
										case 0:
										{
											Color right = this.obhxvquruoqgic();
											num7 = -9;
											continue;
										}
										case 1:
										{
											bool flag;
											if (flag)
											{
												num7 = -24;
												continue;
											}
											goto IL_152;
										}
										case 2:
										{
											RuntimeMethodHandle runtimeMethodHandle2 = methodof(Form1..ctor()).MethodHandle;
											num7 = -10;
											continue;
										}
										case 3:
										{
											Color right;
											bool flag = pixel != right;
											num7 = Form7.mqgfoefwabbyeu(27);
											continue;
										}
										case 4:
											goto IL_14F;
										}
										break;
									}
								}
								IL_155:
								bool flag2;
								if (!flag2)
								{
									arrayList.Add(RuntimeHelpers.GetObjectValue(Versioned.CallByName(pixel, "R", CallType.Get, null)));
									for (;;)
									{
										int num8 = 0;
										for (;;)
										{
											switch (num8 ^ 55)
											{
											case 55:
												arrayList.Add(pixel.G);
												num8 = 15;
												continue;
											case 56:
												arrayList.Add(RuntimeHelpers.GetObjectValue(Versioned.CallByName(pixel, "B", CallType.Get, null)));
												num8 = 13;
												continue;
											case 57:
											{
												RuntimeMethodHandle runtimeMethodHandle3 = methodof(Form1.set_cmdStudent(Button)).MethodHandle;
												num8 = 14;
												continue;
											}
											case 58:
												goto IL_1EB;
											}
											break;
										}
									}
									IL_1EB:;
								}
								num3++;
								break;
								IL_152:
								flag2 = true;
								goto IL_155;
								IL_14F:
								flag2 = false;
								goto IL_155;
							}
							default:
								num2 = 8;
								continue;
							}
							if (num3 <= num5)
							{
								goto IL_7B;
							}
							num4++;
							IL_25B:
							if (num4 > num6)
							{
								goto Block_8;
							}
							goto IL_9F;
						}
						case 62:
							goto IL_3A;
						case 63:
						{
							RuntimeMethodHandle runtimeMethodHandle4 = methodof(Form1.get_cmdExit()).MethodHandle;
							num2 = 9;
							continue;
						}
						case 64:
							goto IL_08;
						}
						IL_25:
						num2 = 11;
						continue;
						IL_08:
						num ^= 61;
						goto IL_25;
					}
				}
				Block_8:
				return (byte[])arrayList.ToArray(typeof(byte));
			}
		}

		// Token: 0x1700001D RID: 29
		// (get) Token: 0x06000051 RID: 81 RVA: 0x00006DB3 File Offset: 0x00004FB3
		// (set) Token: 0x06000052 RID: 82 RVA: 0x00006DC4 File Offset: 0x00004FC4
		internal virtual Button cmdExit
		{
			[CompilerGenerated]
			get
			{
				return this._cmdExit;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.obhxvquruoqgia);
				Button cmdExit = this._cmdExit;
				if (cmdExit != null)
				{
					cmdExit.Click -= value2;
				}
				this._cmdExit = value;
				cmdExit = this._cmdExit;
				if (cmdExit != null)
				{
					cmdExit.Click += value2;
				}
			}
		}

		// Token: 0x1700001E RID: 30
		// (get) Token: 0x06000053 RID: 83 RVA: 0x00006E2F File Offset: 0x0000502F
		// (set) Token: 0x06000054 RID: 84 RVA: 0x00006E40 File Offset: 0x00005040
		internal virtual Button cmdLecturer
		{
			[CompilerGenerated]
			get
			{
				return this._cmdLecturer;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.obhxvquruoqghz);
				Button cmdLecturer = this._cmdLecturer;
				if (cmdLecturer != null)
				{
					cmdLecturer.Click -= value2;
				}
				this._cmdLecturer = value;
				cmdLecturer = this._cmdLecturer;
				if (cmdLecturer != null)
				{
					cmdLecturer.Click += value2;
				}
			}
		}

		// Token: 0x1700001F RID: 31
		// (get) Token: 0x06000055 RID: 85 RVA: 0x00006EAB File Offset: 0x000050AB
		// (set) Token: 0x06000056 RID: 86 RVA: 0x00006EBC File Offset: 0x000050BC
		internal virtual Button cmdStudent
		{
			[CompilerGenerated]
			get
			{
				return this._cmdStudent;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.obhxvquruoqghy);
				Button cmdStudent = this._cmdStudent;
				if (cmdStudent != null)
				{
					cmdStudent.Click -= value2;
				}
				this._cmdStudent = value;
				cmdStudent = this._cmdStudent;
				if (cmdStudent != null)
				{
					cmdStudent.Click += value2;
				}
			}
		}

		// Token: 0x17000020 RID: 32
		// (get) Token: 0x06000057 RID: 87 RVA: 0x00006F27 File Offset: 0x00005127
		// (set) Token: 0x06000058 RID: 88 RVA: 0x00006F38 File Offset: 0x00005138
		internal virtual Button cmdAdmin
		{
			[CompilerGenerated]
			get
			{
				return this._cmdAdmin;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.obhxvquruoqghx);
				Button cmdAdmin = this._cmdAdmin;
				if (cmdAdmin != null)
				{
					cmdAdmin.Click -= value2;
				}
				this._cmdAdmin = value;
				cmdAdmin = this._cmdAdmin;
				if (cmdAdmin != null)
				{
					cmdAdmin.Click += value2;
				}
			}
		}

		// Token: 0x17000021 RID: 33
		// (get) Token: 0x06000059 RID: 89 RVA: 0x00006FA3 File Offset: 0x000051A3
		// (set) Token: 0x0600005A RID: 90 RVA: 0x00006FB1 File Offset: 0x000051B1
		internal virtual Label Label2 { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		// Token: 0x17000022 RID: 34
		// (get) Token: 0x0600005B RID: 91 RVA: 0x00006FBE File Offset: 0x000051BE
		// (set) Token: 0x0600005C RID: 92 RVA: 0x00006FCC File Offset: 0x000051CC
		internal virtual Label Label1 { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		// Token: 0x0400001D RID: 29
		private IContainer components;

		// Token: 0x0400001E RID: 30
		internal ax Button1;
	}
}
