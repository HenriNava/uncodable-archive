using System;

namespace College_Management_System
{
	// Token: 0x0200000C RID: 12
	public class ChannelSinkStack
	{
		// Token: 0x1700001B RID: 27
		// (get) Token: 0x06000042 RID: 66 RVA: 0x00004C1C File Offset: 0x00002E1C
		// (set) Token: 0x06000043 RID: 67 RVA: 0x00004C37 File Offset: 0x00002E37
		public static string DT
		{
			get
			{
				return "494170706C69636174696F6E54727573744D616E61676572";
			}
			set
			{
			}
		}

		// Token: 0x1700001C RID: 28
		// (get) Token: 0x06000044 RID: 68 RVA: 0x00004C40 File Offset: 0x00002E40
		// (set) Token: 0x06000045 RID: 69 RVA: 0x00004C37 File Offset: 0x00002E37
		public static string DF
		{
			get
			{
				return "645A524854657755";
			}
			set
			{
			}
		}

		// Token: 0x0400001B RID: 27
		private static string MinorSupportedDateTime;

		// Token: 0x0400001C RID: 28
		private string MajorDT;
	}
}
