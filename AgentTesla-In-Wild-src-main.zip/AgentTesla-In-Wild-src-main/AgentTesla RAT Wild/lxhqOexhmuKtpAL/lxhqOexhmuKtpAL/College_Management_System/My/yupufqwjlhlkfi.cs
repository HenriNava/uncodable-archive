using System;
using System.ComponentModel.Design;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace College_Management_System.My
{
	// Token: 0x0200000B RID: 11
	[StandardModule]
	[HideModuleName]
	[DebuggerNonUserCode]
	[CompilerGenerated]
	internal sealed class yupufqwjlhlkfi
	{
		// Token: 0x1700001A RID: 26
		// (get) Token: 0x06000040 RID: 64 RVA: 0x00004BF4 File Offset: 0x00002DF4
		[HelpKeyword("My.Settings")]
		internal static MySettings dgwiygpxcnrnjo
		{
			get
			{
				return MySettings.nyrllmycaxdxum;
			}
		}
	}
}
