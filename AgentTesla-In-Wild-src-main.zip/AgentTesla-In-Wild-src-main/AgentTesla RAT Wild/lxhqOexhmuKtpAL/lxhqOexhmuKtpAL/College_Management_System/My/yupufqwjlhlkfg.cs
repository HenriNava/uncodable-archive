using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using Microsoft.VisualBasic.Devices;

namespace College_Management_System.My
{
	// Token: 0x02000003 RID: 3
	[GeneratedCode("MyTemplate", "11.0.0.0")]
	[EditorBrowsable(EditorBrowsableState.Never)]
	internal class yupufqwjlhlkfg : Computer
	{
		// Token: 0x06000004 RID: 4 RVA: 0x000023BE File Offset: 0x000005BE
		[DebuggerHidden]
		[EditorBrowsable(EditorBrowsableState.Never)]
		public yupufqwjlhlkfg()
		{
		}
	}
}
