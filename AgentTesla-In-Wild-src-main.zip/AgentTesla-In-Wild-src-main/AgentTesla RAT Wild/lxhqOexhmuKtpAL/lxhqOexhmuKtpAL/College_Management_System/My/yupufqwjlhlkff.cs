using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.ApplicationServices;

namespace College_Management_System.My
{
	// Token: 0x02000002 RID: 2
	[GeneratedCode("MyTemplate", "11.0.0.0")]
	[EditorBrowsable(EditorBrowsableState.Never)]
	internal class yupufqwjlhlkff : WindowsFormsApplicationBase
	{
		// Token: 0x06000001 RID: 1 RVA: 0x00002050 File Offset: 0x00000250
		[STAThread]
		[DebuggerHidden]
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		[MethodImpl(MethodImplOptions.NoInlining | MethodImplOptions.NoOptimization)]
		internal static void Main(string[] Args)
		{
			try
			{
				Application.SetCompatibleTextRenderingDefault(WindowsFormsApplicationBase.UseCompatibleTextRendering);
			}
			finally
			{
			}
			yupufqwjlhlkfh.whvgmsxtmdbkxv.Run(Args);
		}

		// Token: 0x06000002 RID: 2 RVA: 0x00002090 File Offset: 0x00000290
		[DebuggerStepThrough]
		public yupufqwjlhlkff() : base(AuthenticationMode.Windows)
		{
			for (;;)
			{
				IL_B4:
				int num = Form7.mqgfoefwabbyeu(29);
				int num2 = -13;
				for (;;)
				{
					num2 ^= 24;
					for (;;)
					{
						IL_6D:
						int num3 = 4;
						int num4 = 13;
						for (;;)
						{
							switch (num4 ^ 20)
							{
							case 22:
							{
								RuntimeMethodHandle runtimeMethodHandle = methodof(yupufqwjlhlkff.Main(string[])).MethodHandle;
								num4 = 2;
								continue;
							}
							case 23:
								switch (num3)
								{
								case 23:
									switch (num2 + 24)
									{
									case 0:
										goto IL_B4;
									case 1:
										switch (num + 25)
										{
										case 0:
											num = -14;
											goto IL_17;
										case 1:
											num = -24;
											goto IL_17;
										case 2:
											num = -12;
											goto IL_17;
										case 3:
											base.SaveMySettingsOnExit = true;
											num = -11;
											goto IL_17;
										case 4:
										{
											RuntimeMethodHandle runtimeMethodHandle2 = methodof(yupufqwjlhlkff.OnCreateMainForm()).MethodHandle;
											num = -13;
											goto IL_17;
										}
										case 5:
											base.EnableVisualStyles = true;
											num = Form7.mqgfoefwabbyeu(25);
											goto IL_17;
										case 6:
											num = -9;
											goto IL_17;
										case 7:
											base.IsSingleInstance = false;
											num = -15;
											goto IL_17;
										case 8:
											base.ShutdownStyle = ShutdownMode.AfterMainFormCloses;
											num = -16;
											goto IL_17;
										case 9:
											return;
										}
										goto Block_3;
									case 2:
										goto IL_FD;
									case 3:
										break;
									default:
										num3 = 11;
										goto IL_28;
									}
									IL_17:
									num ^= 24;
									break;
								case 24:
									break;
								case 25:
								{
									RuntimeMethodHandle runtimeMethodHandle3 = methodof(yupufqwjlhlkff.OnCreateMainForm()).MethodHandle;
									num3 = 10;
									goto IL_28;
								}
								case 26:
									goto IL_AF;
								default:
									num4 = 12;
									continue;
								}
								num2 = Form7.mqgfoefwabbyeu(23);
								num3 = 9;
								goto IL_28;
							case 24:
								goto IL_6D;
							case 25:
								goto IL_28;
							}
							IL_41:
							num4 = 3;
							continue;
							IL_28:
							num3 ^= 19;
							goto IL_41;
						}
					}
					IL_AF:
					continue;
					Block_3:
					num2 = -16;
					continue;
					IL_FD:
					RuntimeMethodHandle runtimeMethodHandle4 = methodof(yupufqwjlhlkff.Main(string[])).MethodHandle;
					num2 = -14;
				}
			}
		}

		// Token: 0x06000003 RID: 3 RVA: 0x00002258 File Offset: 0x00000458
		[DebuggerStepThrough]
		protected override void OnCreateMainForm()
		{
			for (;;)
			{
				IL_B5:
				int num = 8;
				int num2 = 14;
				for (;;)
				{
					num2 ^= 36;
					for (;;)
					{
						IL_56:
						int num3 = Form7.mqgfoefwabbyeu(31);
						int num4 = Form2.uwpnsrqhswlmjh(37);
						for (;;)
						{
							num4 ^= 36;
							switch (num4 + 31)
							{
							case 0:
								switch (num3 + 34)
								{
								case 0:
									break;
								case 1:
									switch (num2)
									{
									case 39:
										goto IL_A8;
									case 40:
										goto IL_B5;
									case 41:
										switch (num)
										{
										case 32:
										{
											RuntimeMethodHandle runtimeMethodHandle = methodof(yupufqwjlhlkff.Main(string[])).MethodHandle;
											num = 9;
											goto IL_0B;
										}
										case 33:
											base.MainForm = yupufqwjlhlkfh.whvgmsxtmdbkxx.hcphoarosyelwz;
											num = 11;
											goto IL_0B;
										case 34:
											num = 10;
											goto IL_0B;
										case 35:
											return;
										}
										goto Block_2;
									case 42:
										break;
									default:
										num3 = -4;
										goto IL_19;
									}
									IL_0B:
									num ^= 41;
									break;
								case 2:
								{
									RuntimeMethodHandle runtimeMethodHandle2 = methodof(yupufqwjlhlkff.OnCreateMainForm()).MethodHandle;
									num3 = -62;
									goto IL_19;
								}
								case 3:
									goto IL_A3;
								default:
									num4 = -57;
									continue;
								}
								num2 = 13;
								num3 = Form7.mqgfoefwabbyeu(26);
								goto IL_19;
							case 1:
							{
								RuntimeMethodHandle runtimeMethodHandle3 = methodof(yupufqwjlhlkff..ctor()).MethodHandle;
								num4 = -58;
								continue;
							}
							case 2:
								goto IL_56;
							case 3:
								goto IL_19;
							}
							IL_32:
							num4 = Form7.mqgfoefwabbyeu(33);
							continue;
							IL_19:
							num3 ^= 34;
							goto IL_32;
						}
					}
					IL_A3:
					continue;
					IL_A8:
					RuntimeMethodHandle runtimeMethodHandle4 = methodof(yupufqwjlhlkff.OnCreateMainForm()).MethodHandle;
					num2 = 3;
					continue;
					Block_2:
					num2 = 12;
				}
			}
		}
	}
}
