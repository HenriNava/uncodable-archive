using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.ApplicationServices;
using Microsoft.VisualBasic.CompilerServices;

namespace College_Management_System.My
{
	// Token: 0x02000004 RID: 4
	[StandardModule]
	[HideModuleName]
	[GeneratedCode("MyTemplate", "11.0.0.0")]
	internal sealed class yupufqwjlhlkfh
	{
		// Token: 0x06000005 RID: 5 RVA: 0x000023CC File Offset: 0x000005CC
		// Note: this type is marked as 'beforefieldinit'.
		static yupufqwjlhlkfh()
		{
			for (;;)
			{
				IL_F7:
				int num = 9;
				int num2 = 63;
				for (;;)
				{
					num2 ^= 29;
					for (;;)
					{
						IL_40:
						int num3 = 5;
						int num4 = 11;
						for (;;)
						{
							switch (num4 ^ 22)
							{
							case 26:
								goto IL_40;
							case 27:
							{
								RuntimeMethodHandle runtimeMethodHandle = methodof(yupufqwjlhlkfh.get_whvgmsxtmdbkxx()).MethodHandle;
								num4 = 13;
								continue;
							}
							case 28:
								switch (num3)
								{
								case 29:
									break;
								case 30:
									switch (num2)
									{
									case 31:
										switch (num)
										{
										case 19:
										{
											RuntimeMethodHandle runtimeMethodHandle2 = methodof(yupufqwjlhlkfh.get_whvgmsxtmdbkxy()).MethodHandle;
											num = 13;
											goto IL_14;
										}
										case 20:
											yupufqwjlhlkfh.m_UserObjectProvider = new yupufqwjlhlkfh.jyviwyacpjfptx<User>();
											num = 8;
											goto IL_14;
										case 21:
											yupufqwjlhlkfh.m_MyWebServicesObjectProvider = new yupufqwjlhlkfh.jyviwyacpjfptx<yupufqwjlhlkfh.jyviwyacpjfptw>();
											num = 6;
											goto IL_14;
										case 22:
											yupufqwjlhlkfh.m_MyFormsObjectProvider = new yupufqwjlhlkfh.jyviwyacpjfptx<yupufqwjlhlkfh.jyviwyacpjfptv>();
											num = 11;
											goto IL_14;
										case 23:
											yupufqwjlhlkfh.m_AppObjectProvider = new yupufqwjlhlkfh.jyviwyacpjfptx<yupufqwjlhlkff>();
											num = 10;
											goto IL_14;
										case 24:
											return;
										}
										goto Block_3;
									case 32:
										goto IL_E1;
									case 33:
										goto IL_F7;
									case 34:
										break;
									default:
										num3 = 6;
										goto IL_22;
									}
									IL_14:
									num ^= 30;
									break;
								case 31:
								{
									RuntimeMethodHandle runtimeMethodHandle3 = methodof(yupufqwjlhlkfh..cctor()).MethodHandle;
									num3 = 4;
									goto IL_22;
								}
								case 32:
									goto IL_AB;
								default:
									num4 = 12;
									continue;
								}
								num2 = 2;
								num3 = 59;
								goto IL_22;
							case 29:
								goto IL_22;
							}
							IL_3B:
							num4 = 10;
							continue;
							IL_22:
							num3 ^= 27;
							goto IL_3B;
						}
					}
					IL_AB:
					continue;
					Block_3:
					num2 = 60;
					continue;
					IL_E1:
					RuntimeMethodHandle runtimeMethodHandle4 = methodof(yupufqwjlhlkfh.get_whvgmsxtmdbkxu()).MethodHandle;
					num2 = 61;
				}
			}
		}

		// Token: 0x17000001 RID: 1
		// (get) Token: 0x06000006 RID: 6 RVA: 0x00002558 File Offset: 0x00000758
		[HelpKeyword("My.Computer")]
		internal static yupufqwjlhlkfg whvgmsxtmdbkxu
		{
			[DebuggerHidden]
			get
			{
				yupufqwjlhlkfg wmopvnnhenfnwr;
				for (;;)
				{
					IL_D4:
					int num = 12;
					int num2 = 5;
					for (;;)
					{
						num2 ^= 27;
						for (;;)
						{
							IL_62:
							int num3 = 4;
							int num4 = -16;
							for (;;)
							{
								num4 ^= 24;
								switch (num4 + 27)
								{
								case 0:
									switch (num3)
									{
									case 23:
										break;
									case 24:
										switch (num2)
										{
										case 27:
											goto IL_A2;
										case 28:
											switch (num)
											{
											case 21:
												wmopvnnhenfnwr = yupufqwjlhlkfh.m_ComputerObjectProvider.wmopvnnhenfnwr;
												num = 14;
												goto IL_0B;
											case 22:
											{
												RuntimeMethodHandle runtimeMethodHandle = methodof(yupufqwjlhlkfh.get_whvgmsxtmdbkxw()).MethodHandle;
												num = 15;
												goto IL_0B;
											}
											case 23:
												return wmopvnnhenfnwr;
											case 24:
												return wmopvnnhenfnwr;
											}
											goto Block_2;
										case 29:
											goto IL_D4;
										case 30:
											break;
										default:
											num3 = 11;
											goto IL_19;
										}
										IL_0B:
										num ^= 25;
										break;
									case 25:
									{
										RuntimeMethodHandle runtimeMethodHandle2 = methodof(yupufqwjlhlkfh.get_whvgmsxtmdbkxv()).MethodHandle;
										num3 = 5;
										goto IL_19;
									}
									case 26:
										goto IL_9D;
									default:
										num4 = -1;
										continue;
									}
									num2 = 7;
									num3 = 6;
									goto IL_19;
								case 1:
								{
									RuntimeMethodHandle runtimeMethodHandle3 = methodof(yupufqwjlhlkfh.get_whvgmsxtmdbkxy()).MethodHandle;
									num4 = Form7.mqgfoefwabbyeu(24);
									continue;
								}
								case 2:
									goto IL_62;
								case 3:
									goto IL_19;
								}
								IL_34:
								num4 = Form7.mqgfoefwabbyeu(31);
								continue;
								IL_19:
								num3 ^= 28;
								goto IL_34;
							}
						}
						IL_9D:
						continue;
						IL_A2:
						RuntimeMethodHandle runtimeMethodHandle4 = methodof(yupufqwjlhlkfh.get_whvgmsxtmdbkxw()).MethodHandle;
						num2 = 0;
						continue;
						Block_2:
						num2 = 6;
					}
				}
				return wmopvnnhenfnwr;
			}
		}

		// Token: 0x17000002 RID: 2
		// (get) Token: 0x06000007 RID: 7 RVA: 0x000026B4 File Offset: 0x000008B4
		[HelpKeyword("My.Application")]
		internal static yupufqwjlhlkff whvgmsxtmdbkxv
		{
			[DebuggerHidden]
			get
			{
				yupufqwjlhlkff wmopvnnhenfnwr;
				for (;;)
				{
					IL_A2:
					int num = Form7.mqgfoefwabbyeu(21);
					int num2 = 9;
					for (;;)
					{
						num2 ^= 23;
						for (;;)
						{
							IL_3C:
							int num3 = Form7.mqgfoefwabbyeu(32);
							int num4 = 14;
							for (;;)
							{
								switch (num4 ^ 38)
								{
								case 37:
									goto IL_3C;
								case 38:
									switch (num3 + 22)
									{
									case 0:
									{
										RuntimeMethodHandle runtimeMethodHandle = methodof(yupufqwjlhlkfh.get_whvgmsxtmdbkxu()).MethodHandle;
										num3 = -10;
										goto IL_1C;
									}
									case 1:
										switch (num2)
										{
										case 27:
											goto IL_A2;
										case 28:
											switch (num + 19)
											{
											case 0:
												wmopvnnhenfnwr = yupufqwjlhlkfh.m_AppObjectProvider.wmopvnnhenfnwr;
												num = Form7.mqgfoefwabbyeu(23);
												goto IL_0B;
											case 1:
											{
												RuntimeMethodHandle runtimeMethodHandle2 = methodof(yupufqwjlhlkfh.get_whvgmsxtmdbkxx()).MethodHandle;
												num = -16;
												goto IL_0B;
											}
											case 2:
												return wmopvnnhenfnwr;
											case 3:
												return wmopvnnhenfnwr;
											}
											goto Block_2;
										case 29:
											goto IL_EF;
										case 30:
											break;
										default:
											num3 = -16;
											goto IL_1C;
										}
										IL_0B:
										num ^= 30;
										break;
									case 2:
										break;
									case 3:
										goto IL_9D;
									default:
										num4 = 3;
										continue;
									}
									num2 = 11;
									num3 = -15;
									goto IL_1C;
								case 39:
								{
									RuntimeMethodHandle runtimeMethodHandle3 = methodof(yupufqwjlhlkfh.get_whvgmsxtmdbkxx()).MethodHandle;
									num4 = 1;
									continue;
								}
								case 40:
									goto IL_1C;
								}
								IL_37:
								num4 = 0;
								continue;
								IL_1C:
								num3 ^= 28;
								goto IL_37;
							}
						}
						IL_9D:
						continue;
						Block_2:
						num2 = 12;
						continue;
						IL_EF:
						RuntimeMethodHandle runtimeMethodHandle4 = methodof(yupufqwjlhlkfh.get_whvgmsxtmdbkxy()).MethodHandle;
						num2 = 10;
					}
				}
				return wmopvnnhenfnwr;
			}
		}

		// Token: 0x17000003 RID: 3
		// (get) Token: 0x06000008 RID: 8 RVA: 0x00002824 File Offset: 0x00000A24
		[HelpKeyword("My.User")]
		internal static User whvgmsxtmdbkxw
		{
			[DebuggerHidden]
			get
			{
				User wmopvnnhenfnwr;
				for (;;)
				{
					IL_E1:
					int num = 14;
					int num2 = Form2.uwpnsrqhswlmjh(44);
					for (;;)
					{
						num2 ^= 31;
						for (;;)
						{
							IL_42:
							int num3 = Form12.wsyoqrrjsoniul(41);
							int num4 = -9;
							for (;;)
							{
								num4 ^= 44;
								switch (num4 + 40)
								{
								case 0:
									goto IL_42;
								case 1:
								{
									RuntimeMethodHandle runtimeMethodHandle = methodof(yupufqwjlhlkfh..cctor()).MethodHandle;
									num4 = Form7.mqgfoefwabbyeu(27);
									continue;
								}
								case 2:
									switch (num3 + 50)
									{
									case 0:
									{
										RuntimeMethodHandle runtimeMethodHandle2 = methodof(yupufqwjlhlkfh..cctor()).MethodHandle;
										num3 = Form2.uwpnsrqhswlmjh(45);
										goto IL_1C;
									}
									case 1:
										switch (num2 + 30)
										{
										case 0:
											goto IL_D3;
										case 1:
											goto IL_E1;
										case 2:
											switch (num)
											{
											case 38:
											{
												RuntimeMethodHandle runtimeMethodHandle3 = methodof(yupufqwjlhlkfh.get_whvgmsxtmdbkxy()).MethodHandle;
												num = 0;
												goto IL_0B;
											}
											case 39:
												return wmopvnnhenfnwr;
											case 40:
												wmopvnnhenfnwr = yupufqwjlhlkfh.m_UserObjectProvider.wmopvnnhenfnwr;
												num = 1;
												goto IL_0B;
											case 41:
												return wmopvnnhenfnwr;
											}
											goto Block_3;
										case 3:
											break;
										default:
											num3 = -9;
											goto IL_1C;
										}
										IL_0B:
										num ^= 38;
										break;
									case 2:
										break;
									case 3:
										goto IL_CE;
									default:
										num4 = -12;
										continue;
									}
									num2 = Form2.uwpnsrqhswlmjh(34);
									num3 = -10;
									goto IL_1C;
								case 3:
									goto IL_1C;
								}
								IL_37:
								num4 = Form7.mqgfoefwabbyeu(29);
								continue;
								IL_1C:
								num3 ^= 39;
								goto IL_37;
							}
						}
						IL_CE:
						continue;
						IL_D3:
						RuntimeMethodHandle runtimeMethodHandle4 = methodof(yupufqwjlhlkfh.get_whvgmsxtmdbkxy()).MethodHandle;
						num2 = -3;
						continue;
						Block_3:
						num2 = -4;
					}
				}
				return wmopvnnhenfnwr;
			}
		}

		// Token: 0x17000004 RID: 4
		// (get) Token: 0x06000009 RID: 9 RVA: 0x000029A8 File Offset: 0x00000BA8
		[HelpKeyword("My.Forms")]
		internal static yupufqwjlhlkfh.jyviwyacpjfptv whvgmsxtmdbkxx
		{
			[DebuggerHidden]
			get
			{
				yupufqwjlhlkfh.jyviwyacpjfptv wmopvnnhenfnwr;
				for (;;)
				{
					IL_CE:
					int num = Form12.wsyoqrrjsoniul(48);
					int num2 = -1;
					for (;;)
					{
						num2 ^= 45;
						for (;;)
						{
							IL_42:
							int num3 = Form2.uwpnsrqhswlmjh(47);
							int num4 = -4;
							for (;;)
							{
								num4 ^= 54;
								switch (num4 + 57)
								{
								case 0:
									goto IL_42;
								case 1:
								{
									RuntimeMethodHandle runtimeMethodHandle = methodof(yupufqwjlhlkfh..cctor()).MethodHandle;
									num4 = Form7.mqgfoefwabbyeu(24);
									continue;
								}
								case 2:
									switch (num3 + 52)
									{
									case 0:
										switch (num2 + 49)
										{
										case 0:
											goto IL_CE;
										case 1:
											switch (num + 45)
											{
											case 0:
												wmopvnnhenfnwr = yupufqwjlhlkfh.m_MyFormsObjectProvider.wmopvnnhenfnwr;
												num = Form12.wsyoqrrjsoniul(49);
												goto IL_0B;
											case 1:
											{
												RuntimeMethodHandle runtimeMethodHandle2 = methodof(yupufqwjlhlkfh.get_whvgmsxtmdbkxx()).MethodHandle;
												num = -25;
												goto IL_0B;
											}
											case 2:
												return wmopvnnhenfnwr;
											case 3:
												return wmopvnnhenfnwr;
											}
											goto Block_3;
										case 2:
											goto IL_106;
										case 3:
											break;
										default:
											num3 = -32;
											goto IL_1C;
										}
										IL_0B:
										num ^= 51;
										break;
									case 1:
										break;
									case 2:
									{
										RuntimeMethodHandle runtimeMethodHandle3 = methodof(yupufqwjlhlkfh..cctor()).MethodHandle;
										num3 = -29;
										goto IL_1C;
									}
									case 3:
										goto IL_C9;
									default:
										num4 = -15;
										continue;
									}
									num2 = Form7.mqgfoefwabbyeu(31);
									num3 = -30;
									goto IL_1C;
								case 3:
									goto IL_1C;
								}
								IL_37:
								num4 = Form7.mqgfoefwabbyeu(25);
								continue;
								IL_1C:
								num3 ^= 45;
								goto IL_37;
							}
						}
						IL_C9:
						continue;
						Block_3:
						num2 = -30;
						continue;
						IL_106:
						RuntimeMethodHandle runtimeMethodHandle4 = methodof(yupufqwjlhlkfh.get_whvgmsxtmdbkxy()).MethodHandle;
						num2 = Form2.uwpnsrqhswlmjh(42);
					}
				}
				return wmopvnnhenfnwr;
			}
		}

		// Token: 0x17000005 RID: 5
		// (get) Token: 0x0600000A RID: 10 RVA: 0x00002B34 File Offset: 0x00000D34
		[HelpKeyword("My.WebServices")]
		internal static yupufqwjlhlkfh.jyviwyacpjfptw whvgmsxtmdbkxy
		{
			[DebuggerHidden]
			get
			{
				yupufqwjlhlkfh.jyviwyacpjfptw wmopvnnhenfnwr;
				for (;;)
				{
					IL_E4:
					int num = Form7.mqgfoefwabbyeu(27);
					int num2 = 2;
					for (;;)
					{
						num2 ^= 62;
						for (;;)
						{
							IL_57:
							int num3 = Form7.mqgfoefwabbyeu(23);
							int num4 = 1;
							for (;;)
							{
								switch (num4 ^ 59)
								{
								case 55:
								{
									RuntimeMethodHandle runtimeMethodHandle = methodof(yupufqwjlhlkfh.get_whvgmsxtmdbkxw()).MethodHandle;
									num4 = 12;
									continue;
								}
								case 56:
									switch (num3 + 54)
									{
									case 0:
										break;
									case 1:
										switch (num2)
										{
										case 57:
											switch (num + 53)
											{
											case 0:
											{
												RuntimeMethodHandle runtimeMethodHandle2 = methodof(yupufqwjlhlkfh.get_whvgmsxtmdbkxx()).MethodHandle;
												num = Form12.wsyoqrrjsoniul(53);
												goto IL_0B;
											}
											case 1:
												wmopvnnhenfnwr = yupufqwjlhlkfh.m_MyWebServicesObjectProvider.wmopvnnhenfnwr;
												num = -12;
												goto IL_0B;
											case 2:
												return wmopvnnhenfnwr;
											case 3:
												return wmopvnnhenfnwr;
											}
											goto Block_2;
										case 58:
											goto IL_BB;
										case 59:
											goto IL_E4;
										case 60:
											break;
										default:
											num3 = -16;
											goto IL_19;
										}
										IL_0B:
										num ^= 57;
										break;
									case 2:
									{
										RuntimeMethodHandle runtimeMethodHandle3 = methodof(yupufqwjlhlkfh.get_whvgmsxtmdbkxx()).MethodHandle;
										num3 = -10;
										goto IL_19;
									}
									case 3:
										goto IL_96;
									default:
										num4 = 2;
										continue;
									}
									num2 = 7;
									num3 = -9;
									goto IL_19;
								case 57:
									goto IL_57;
								case 58:
									goto IL_19;
								}
								IL_34:
								num4 = 3;
								continue;
								IL_19:
								num3 ^= 58;
								goto IL_34;
							}
						}
						IL_96:
						continue;
						Block_2:
						num2 = 5;
						continue;
						IL_BB:
						RuntimeMethodHandle runtimeMethodHandle4 = methodof(yupufqwjlhlkfh.get_whvgmsxtmdbkxv()).MethodHandle;
						num2 = 4;
					}
				}
				return wmopvnnhenfnwr;
			}
		}

		// Token: 0x04000001 RID: 1
		private static readonly yupufqwjlhlkfh.jyviwyacpjfptx<yupufqwjlhlkfg> m_ComputerObjectProvider = new yupufqwjlhlkfh.jyviwyacpjfptx<yupufqwjlhlkfg>();

		// Token: 0x04000002 RID: 2
		private static readonly yupufqwjlhlkfh.jyviwyacpjfptx<yupufqwjlhlkff> m_AppObjectProvider;

		// Token: 0x04000003 RID: 3
		private static readonly yupufqwjlhlkfh.jyviwyacpjfptx<User> m_UserObjectProvider;

		// Token: 0x04000004 RID: 4
		private static yupufqwjlhlkfh.jyviwyacpjfptx<yupufqwjlhlkfh.jyviwyacpjfptv> m_MyFormsObjectProvider;

		// Token: 0x04000005 RID: 5
		private static readonly yupufqwjlhlkfh.jyviwyacpjfptx<yupufqwjlhlkfh.jyviwyacpjfptw> m_MyWebServicesObjectProvider;

		// Token: 0x02000005 RID: 5
		[EditorBrowsable(EditorBrowsableState.Never)]
		[MyGroupCollection("System.Windows.Forms.Form", "Create__Instance__", "Dispose__Instance__", "My.MyProject.Forms")]
		internal sealed class jyviwyacpjfptv
		{
			// Token: 0x0600000B RID: 11 RVA: 0x00002C98 File Offset: 0x00000E98
			[DebuggerHidden]
			private static a rhkqqdrxlawrtf<a>(a a) where a : Form, new()
			{
				bool flag = a == null || a.IsDisposed;
				if (flag)
				{
					bool flag2 = yupufqwjlhlkfh.jyviwyacpjfptv.m_FormBeingCreated != null;
					if (flag2)
					{
						bool flag3 = yupufqwjlhlkfh.jyviwyacpjfptv.m_FormBeingCreated.ContainsKey(typeof(a));
						if (flag3)
						{
							throw new InvalidOperationException(Utils.GetResourceString("WinForms_RecursiveFormCreate", new string[0]));
						}
					}
					else
					{
						yupufqwjlhlkfh.jyviwyacpjfptv.m_FormBeingCreated = new Hashtable();
					}
					yupufqwjlhlkfh.jyviwyacpjfptv.m_FormBeingCreated.Add(typeof(a), null);
					TargetInvocationException ex3;
					object obj;
					TargetInvocationException ex2;
					TargetInvocationException ex;
					bool flag4;
					bool flag5;
					try
					{
						return Activator.CreateInstance<a>();
					}
					catch when (delegate
					{
						// Failed to create a 'catch-when' expression
						ex = (ex2 = (obj as TargetInvocationException));
						if (ex2 == null)
						{
							flag4 = false;
						}
						else
						{
							ex3 = ex;
							flag5 = (ex3.InnerException != null);
							flag4 = (flag5 > false);
						}
						endfilter(flag4);
					})
					{
						string resourceString = Utils.GetResourceString("WinForms_SeeInnerException", new string[]
						{
							ex3.InnerException.Message
						});
						throw new InvalidOperationException(resourceString, ex3.InnerException);
					}
					finally
					{
						yupufqwjlhlkfh.jyviwyacpjfptv.m_FormBeingCreated.Remove(typeof(a));
					}
				}
				return a;
			}

			// Token: 0x0600000C RID: 12 RVA: 0x00002E20 File Offset: 0x00001020
			[DebuggerHidden]
			private void rhkqqdrxlawrtg<a>(ref a b) where a : Form
			{
				for (;;)
				{
					IL_B2:
					int num = 2;
					int num2 = -15;
					for (;;)
					{
						num2 ^= 24;
						for (;;)
						{
							IL_61:
							int num3 = Form7.mqgfoefwabbyeu(26);
							int num4 = -1;
							for (;;)
							{
								num4 ^= 30;
								switch (num4 + 34)
								{
								case 0:
								{
									RuntimeMethodHandle runtimeMethodHandle = methodof(yupufqwjlhlkfh.jyviwyacpjfptv.get_hcphoarosyelxb()).MethodHandle;
									num4 = -64;
									continue;
								}
								case 1:
									switch (num3 + 29)
									{
									case 0:
										switch (num2 + 26)
										{
										case 0:
											goto IL_B2;
										case 1:
											switch (num)
											{
											case 27:
											{
												RuntimeMethodHandle runtimeMethodHandle2 = methodof(yupufqwjlhlkfh.jyviwyacpjfptv.set_hcphoarosyelxi(Form7)).MethodHandle;
												num = 5;
												goto IL_0B;
											}
											case 28:
												b.Dispose();
												num = 3;
												goto IL_0B;
											case 29:
												b = default(a);
												num = 0;
												goto IL_0B;
											case 30:
												return;
											}
											goto Block_2;
										case 2:
											goto IL_DD;
										case 3:
											break;
										default:
											num3 = -59;
											goto IL_1C;
										}
										IL_0B:
										num ^= 30;
										break;
									case 1:
									{
										RuntimeMethodHandle runtimeMethodHandle3 = methodof(yupufqwjlhlkfh.jyviwyacpjfptv.set_hcphoarosyelxa(Form10)).MethodHandle;
										num3 = -60;
										goto IL_1C;
									}
									case 2:
										break;
									case 3:
										goto IL_AD;
									default:
										num4 = Form7.mqgfoefwabbyeu(24);
										continue;
									}
									num2 = Form7.mqgfoefwabbyeu(25);
									num3 = Form7.mqgfoefwabbyeu(28);
									goto IL_1C;
								case 2:
									goto IL_61;
								case 3:
									goto IL_1C;
								}
								IL_35:
								num4 = Form7.mqgfoefwabbyeu(35);
								continue;
								IL_1C:
								num3 ^= 32;
								goto IL_35;
							}
						}
						IL_AD:
						continue;
						Block_2:
						num2 = -2;
						continue;
						IL_DD:
						RuntimeMethodHandle runtimeMethodHandle4 = methodof(yupufqwjlhlkfh.jyviwyacpjfptv.get_hcphoarosyelxg()).MethodHandle;
						num2 = Form7.mqgfoefwabbyeu(19);
					}
				}
			}

			// Token: 0x0600000D RID: 13 RVA: 0x00002F99 File Offset: 0x00001199
			[DebuggerHidden]
			[EditorBrowsable(EditorBrowsableState.Never)]
			public jyviwyacpjfptv()
			{
			}

			// Token: 0x0600000E RID: 14 RVA: 0x00002FA8 File Offset: 0x000011A8
			[EditorBrowsable(EditorBrowsableState.Never)]
			public override bool Equals(object o)
			{
				bool result;
				for (;;)
				{
					IL_E3:
					int num = 62;
					int num2 = 58;
					for (;;)
					{
						num2 ^= 31;
						for (;;)
						{
							IL_4B:
							int num3 = 4;
							int num4 = 0;
							for (;;)
							{
								switch (num4 ^ 38)
								{
								case 35:
								{
									RuntimeMethodHandle runtimeMethodHandle = methodof(yupufqwjlhlkfh.jyviwyacpjfptv.get_hcphoarosyelxd()).MethodHandle;
									num4 = 5;
									continue;
								}
								case 36:
									goto IL_4B;
								case 37:
									switch (num3)
									{
									case 36:
									{
										RuntimeMethodHandle runtimeMethodHandle2 = methodof(yupufqwjlhlkfh.jyviwyacpjfptv.get_hcphoarosyelxa()).MethodHandle;
										num3 = 6;
										goto IL_1C;
									}
									case 37:
										break;
									case 38:
										switch (num2)
										{
										case 34:
											goto IL_AC;
										case 35:
											switch (num)
											{
											case 31:
												return result;
											case 32:
											{
												RuntimeMethodHandle runtimeMethodHandle3 = methodof(yupufqwjlhlkfh.jyviwyacpjfptv.GetHashCode()).MethodHandle;
												num = 63;
												goto IL_0B;
											}
											case 33:
												result = base.Equals(RuntimeHelpers.GetObjectValue(o));
												num = 0;
												goto IL_0B;
											case 34:
												return result;
											}
											goto Block_3;
										case 36:
											goto IL_E3;
										case 37:
											break;
										default:
											num3 = 7;
											goto IL_1C;
										}
										IL_0B:
										num ^= 31;
										break;
									case 39:
										goto IL_A7;
									default:
										num4 = 2;
										continue;
									}
									num2 = 60;
									num3 = 5;
									goto IL_1C;
								case 38:
									goto IL_1C;
								}
								IL_37:
								num4 = 3;
								continue;
								IL_1C:
								num3 ^= 34;
								goto IL_37;
							}
						}
						IL_A7:
						continue;
						IL_AC:
						RuntimeMethodHandle runtimeMethodHandle4 = methodof(yupufqwjlhlkfh.jyviwyacpjfptv.set_hcphoarosyelxb(Form11)).MethodHandle;
						num2 = 61;
						continue;
						Block_3:
						num2 = 59;
					}
				}
				return result;
			}

			// Token: 0x0600000F RID: 15 RVA: 0x00003104 File Offset: 0x00001304
			[EditorBrowsable(EditorBrowsableState.Never)]
			public override int GetHashCode()
			{
				int hashCode;
				for (;;)
				{
					IL_FB:
					int num = Form7.mqgfoefwabbyeu(31);
					int num2 = -9;
					for (;;)
					{
						num2 ^= 45;
						for (;;)
						{
							IL_3F:
							int num3 = 28;
							int num4 = -8;
							for (;;)
							{
								num4 ^= 52;
								switch (num4 + 55)
								{
								case 0:
									goto IL_3F;
								case 1:
									switch (num3)
									{
									case 48:
										break;
									case 49:
									{
										RuntimeMethodHandle runtimeMethodHandle = methodof(yupufqwjlhlkfh.jyviwyacpjfptv.rhkqqdrxlawrth()).MethodHandle;
										num3 = 31;
										goto IL_19;
									}
									case 50:
										switch (num2 + 41)
										{
										case 0:
											goto IL_AB;
										case 1:
											switch (num + 43)
											{
											case 0:
											{
												RuntimeMethodHandle runtimeMethodHandle2 = methodof(yupufqwjlhlkfh.jyviwyacpjfptv.Equals(object)).MethodHandle;
												num = Form7.mqgfoefwabbyeu(24);
												goto IL_0B;
											}
											case 1:
												hashCode = base.GetHashCode();
												num = -4;
												goto IL_0B;
											case 2:
												return hashCode;
											case 3:
												return hashCode;
											}
											goto Block_2;
										case 2:
											goto IL_FB;
										case 3:
											break;
										default:
											num3 = 30;
											goto IL_19;
										}
										IL_0B:
										num ^= 43;
										break;
									case 51:
										goto IL_A6;
									default:
										num4 = Form7.mqgfoefwabbyeu(31);
										continue;
									}
									num2 = Form7.mqgfoefwabbyeu(27);
									num3 = 29;
									goto IL_19;
								case 2:
								{
									RuntimeMethodHandle runtimeMethodHandle3 = methodof(yupufqwjlhlkfh.jyviwyacpjfptv.get_hcphoarosyelxd()).MethodHandle;
									num4 = -1;
									continue;
								}
								case 3:
									goto IL_19;
								}
								IL_34:
								num4 = Form7.mqgfoefwabbyeu(24);
								continue;
								IL_19:
								num3 ^= 46;
								goto IL_34;
							}
						}
						IL_A6:
						continue;
						IL_AB:
						RuntimeMethodHandle runtimeMethodHandle4 = methodof(yupufqwjlhlkfh.jyviwyacpjfptv.set_hcphoarosyelxf(Form4)).MethodHandle;
						num2 = Form2.uwpnsrqhswlmjh(44);
						continue;
						Block_2:
						num2 = -12;
					}
				}
				return hashCode;
			}

			// Token: 0x06000010 RID: 16 RVA: 0x0000327C File Offset: 0x0000147C
			[EditorBrowsable(EditorBrowsableState.Never)]
			internal unsafe Type rhkqqdrxlawrth()
			{
				Type typeFromHandle;
				for (;;)
				{
					IL_C5:
					int num = 0;
					int num2 = 7;
					for (;;)
					{
						num2 ^= 60;
						for (;;)
						{
							IL_3A:
							int num3 = Form7.mqgfoefwabbyeu(32);
							int num4 = 8;
							for (;;)
							{
								switch (num4 ^ 60)
								{
								case 49:
									goto IL_3A;
								case 50:
									switch (num3 + 60)
									{
									case 0:
									{
										RuntimeMethodHandle runtimeMethodHandle = methodof(yupufqwjlhlkfh.jyviwyacpjfptv.rhkqqdrxlawrtg(a*)).MethodHandle;
										num3 = Form7.mqgfoefwabbyeu(27);
										goto IL_19;
									}
									case 1:
										break;
									case 2:
										switch (num2)
										{
										case 56:
											switch (num)
											{
											case 51:
												return typeFromHandle;
											case 52:
											{
												RuntimeMethodHandle runtimeMethodHandle2 = methodof(yupufqwjlhlkfh.jyviwyacpjfptv.get_hcphoarosyelxh()).MethodHandle;
												num = 1;
												goto IL_0B;
											}
											case 53:
												typeFromHandle = typeof(yupufqwjlhlkfh.jyviwyacpjfptv);
												num = 6;
												goto IL_0B;
											case 54:
												return typeFromHandle;
											}
											goto Block_2;
										case 57:
											goto IL_C5;
										case 58:
											goto IL_EA;
										case 59:
											break;
										default:
											num3 = -12;
											goto IL_19;
										}
										IL_0B:
										num ^= 53;
										break;
									case 3:
										goto IL_A0;
									default:
										num4 = 13;
										continue;
									}
									num2 = 4;
									num3 = -10;
									goto IL_19;
								case 51:
								{
									RuntimeMethodHandle runtimeMethodHandle3 = methodof(yupufqwjlhlkfh.jyviwyacpjfptv.set_hcphoarosyelwz(Form1)).MethodHandle;
									num4 = 15;
									continue;
								}
								case 52:
									goto IL_19;
								}
								IL_34:
								num4 = 14;
								continue;
								IL_19:
								num3 ^= 49;
								goto IL_34;
							}
						}
						IL_A0:
						continue;
						Block_2:
						num2 = 5;
						continue;
						IL_EA:
						RuntimeMethodHandle runtimeMethodHandle4 = methodof(yupufqwjlhlkfh.jyviwyacpjfptv.GetHashCode()).MethodHandle;
						num2 = 6;
					}
				}
				return typeFromHandle;
			}

			// Token: 0x06000011 RID: 17 RVA: 0x000033DC File Offset: 0x000015DC
			[EditorBrowsable(EditorBrowsableState.Never)]
			public override string ToString()
			{
				string result;
				for (;;)
				{
					IL_C8:
					int num = Form7.mqgfoefwabbyeu(32);
					int num2 = 6;
					for (;;)
					{
						num2 ^= 58;
						for (;;)
						{
							IL_4B:
							int num3 = Form7.mqgfoefwabbyeu(23);
							int num4 = 7;
							for (;;)
							{
								switch (num4 ^ 62)
								{
								case 54:
								{
									RuntimeMethodHandle runtimeMethodHandle = methodof(yupufqwjlhlkfh.jyviwyacpjfptv.ToString()).MethodHandle;
									num4 = 8;
									continue;
								}
								case 55:
									goto IL_4B;
								case 56:
									switch (num3 + 60)
									{
									case 0:
										switch (num2)
										{
										case 57:
											goto IL_BB;
										case 58:
											goto IL_C8;
										case 59:
											switch (num + 52)
											{
											case 0:
											{
												RuntimeMethodHandle runtimeMethodHandle2 = methodof(yupufqwjlhlkfh.jyviwyacpjfptv.rhkqqdrxlawrth()).MethodHandle;
												num = -11;
												goto IL_0B;
											}
											case 1:
												return result;
											case 2:
												result = base.ToString();
												num = Form12.wsyoqrrjsoniul(58);
												goto IL_0B;
											case 3:
												return result;
											}
											goto Block_3;
										case 60:
											break;
										default:
											num3 = -13;
											goto IL_1C;
										}
										IL_0B:
										num ^= 57;
										break;
									case 1:
									{
										RuntimeMethodHandle runtimeMethodHandle3 = methodof(yupufqwjlhlkfh.jyviwyacpjfptv.set_hcphoarosyelxe(Form3)).MethodHandle;
										num3 = -16;
										goto IL_1C;
									}
									case 2:
										break;
									case 3:
										goto IL_B6;
									default:
										num4 = 9;
										continue;
									}
									num2 = 1;
									num3 = -14;
									goto IL_1C;
								case 57:
									goto IL_1C;
								}
								IL_37:
								num4 = 6;
								continue;
								IL_1C:
								num3 ^= 53;
								goto IL_37;
							}
						}
						IL_B6:
						continue;
						IL_BB:
						RuntimeMethodHandle runtimeMethodHandle4 = methodof(yupufqwjlhlkfh.jyviwyacpjfptv.get_hcphoarosyelxi()).MethodHandle;
						num2 = 3;
						continue;
						Block_3:
						num2 = 0;
					}
				}
				return result;
			}

			// Token: 0x17000006 RID: 6
			// (get) Token: 0x06000012 RID: 18 RVA: 0x00003547 File Offset: 0x00001747
			// (set) Token: 0x0600001E RID: 30 RVA: 0x000036BC File Offset: 0x000018BC
			public Form1 hcphoarosyelwz
			{
				[DebuggerHidden]
				get
				{
					this.m_Form1 = yupufqwjlhlkfh.jyviwyacpjfptv.rhkqqdrxlawrtf<Form1>(this.m_Form1);
					return this.m_Form1;
				}
				[DebuggerHidden]
				set
				{
					if (value != this.m_Form1)
					{
						if (value != null)
						{
							throw new ArgumentException("Property can only be set to Nothing");
						}
						this.rhkqqdrxlawrtg<Form1>(ref this.m_Form1);
					}
				}
			}

			// Token: 0x17000007 RID: 7
			// (get) Token: 0x06000013 RID: 19 RVA: 0x00003566 File Offset: 0x00001766
			// (set) Token: 0x0600001F RID: 31 RVA: 0x00003710 File Offset: 0x00001910
			public Form10 hcphoarosyelxa
			{
				[DebuggerHidden]
				get
				{
					this.m_Form10 = yupufqwjlhlkfh.jyviwyacpjfptv.rhkqqdrxlawrtf<Form10>(this.m_Form10);
					return this.m_Form10;
				}
				[DebuggerHidden]
				set
				{
					if (value != this.m_Form10)
					{
						if (value != null)
						{
							throw new ArgumentException("Property can only be set to Nothing");
						}
						this.rhkqqdrxlawrtg<Form10>(ref this.m_Form10);
					}
				}
			}

			// Token: 0x17000008 RID: 8
			// (get) Token: 0x06000014 RID: 20 RVA: 0x00003585 File Offset: 0x00001785
			// (set) Token: 0x06000020 RID: 32 RVA: 0x00003764 File Offset: 0x00001964
			public Form11 hcphoarosyelxb
			{
				[DebuggerHidden]
				get
				{
					this.m_Form11 = yupufqwjlhlkfh.jyviwyacpjfptv.rhkqqdrxlawrtf<Form11>(this.m_Form11);
					return this.m_Form11;
				}
				[DebuggerHidden]
				set
				{
					if (value != this.m_Form11)
					{
						if (value != null)
						{
							throw new ArgumentException("Property can only be set to Nothing");
						}
						this.rhkqqdrxlawrtg<Form11>(ref this.m_Form11);
					}
				}
			}

			// Token: 0x17000009 RID: 9
			// (get) Token: 0x06000015 RID: 21 RVA: 0x000035A4 File Offset: 0x000017A4
			// (set) Token: 0x06000021 RID: 33 RVA: 0x000037B8 File Offset: 0x000019B8
			public Form12 hcphoarosyelxc
			{
				[DebuggerHidden]
				get
				{
					this.m_Form12 = yupufqwjlhlkfh.jyviwyacpjfptv.rhkqqdrxlawrtf<Form12>(this.m_Form12);
					return this.m_Form12;
				}
				[DebuggerHidden]
				set
				{
					if (value != this.m_Form12)
					{
						if (value != null)
						{
							throw new ArgumentException("Property can only be set to Nothing");
						}
						this.rhkqqdrxlawrtg<Form12>(ref this.m_Form12);
					}
				}
			}

			// Token: 0x1700000A RID: 10
			// (get) Token: 0x06000016 RID: 22 RVA: 0x000035C3 File Offset: 0x000017C3
			// (set) Token: 0x06000022 RID: 34 RVA: 0x0000380C File Offset: 0x00001A0C
			public Form2 hcphoarosyelxd
			{
				[DebuggerHidden]
				get
				{
					this.m_Form2 = yupufqwjlhlkfh.jyviwyacpjfptv.rhkqqdrxlawrtf<Form2>(this.m_Form2);
					return this.m_Form2;
				}
				[DebuggerHidden]
				set
				{
					if (value != this.m_Form2)
					{
						if (value != null)
						{
							throw new ArgumentException("Property can only be set to Nothing");
						}
						this.rhkqqdrxlawrtg<Form2>(ref this.m_Form2);
					}
				}
			}

			// Token: 0x1700000B RID: 11
			// (get) Token: 0x06000017 RID: 23 RVA: 0x000035E2 File Offset: 0x000017E2
			// (set) Token: 0x06000023 RID: 35 RVA: 0x00003860 File Offset: 0x00001A60
			public Form3 hcphoarosyelxe
			{
				[DebuggerHidden]
				get
				{
					this.m_Form3 = yupufqwjlhlkfh.jyviwyacpjfptv.rhkqqdrxlawrtf<Form3>(this.m_Form3);
					return this.m_Form3;
				}
				[DebuggerHidden]
				set
				{
					if (value != this.m_Form3)
					{
						if (value != null)
						{
							throw new ArgumentException("Property can only be set to Nothing");
						}
						this.rhkqqdrxlawrtg<Form3>(ref this.m_Form3);
					}
				}
			}

			// Token: 0x1700000C RID: 12
			// (get) Token: 0x06000018 RID: 24 RVA: 0x00003601 File Offset: 0x00001801
			// (set) Token: 0x06000024 RID: 36 RVA: 0x000038B4 File Offset: 0x00001AB4
			public Form4 hcphoarosyelxf
			{
				[DebuggerHidden]
				get
				{
					this.m_Form4 = yupufqwjlhlkfh.jyviwyacpjfptv.rhkqqdrxlawrtf<Form4>(this.m_Form4);
					return this.m_Form4;
				}
				[DebuggerHidden]
				set
				{
					if (value != this.m_Form4)
					{
						if (value != null)
						{
							throw new ArgumentException("Property can only be set to Nothing");
						}
						this.rhkqqdrxlawrtg<Form4>(ref this.m_Form4);
					}
				}
			}

			// Token: 0x1700000D RID: 13
			// (get) Token: 0x06000019 RID: 25 RVA: 0x00003620 File Offset: 0x00001820
			// (set) Token: 0x06000025 RID: 37 RVA: 0x00003908 File Offset: 0x00001B08
			public Form5 hcphoarosyelxg
			{
				[DebuggerHidden]
				get
				{
					this.m_Form5 = yupufqwjlhlkfh.jyviwyacpjfptv.rhkqqdrxlawrtf<Form5>(this.m_Form5);
					return this.m_Form5;
				}
				[DebuggerHidden]
				set
				{
					if (value != this.m_Form5)
					{
						if (value != null)
						{
							throw new ArgumentException("Property can only be set to Nothing");
						}
						this.rhkqqdrxlawrtg<Form5>(ref this.m_Form5);
					}
				}
			}

			// Token: 0x1700000E RID: 14
			// (get) Token: 0x0600001A RID: 26 RVA: 0x0000363F File Offset: 0x0000183F
			// (set) Token: 0x06000026 RID: 38 RVA: 0x0000395C File Offset: 0x00001B5C
			public Form6 hcphoarosyelxh
			{
				[DebuggerHidden]
				get
				{
					this.m_Form6 = yupufqwjlhlkfh.jyviwyacpjfptv.rhkqqdrxlawrtf<Form6>(this.m_Form6);
					return this.m_Form6;
				}
				[DebuggerHidden]
				set
				{
					if (value != this.m_Form6)
					{
						if (value != null)
						{
							throw new ArgumentException("Property can only be set to Nothing");
						}
						this.rhkqqdrxlawrtg<Form6>(ref this.m_Form6);
					}
				}
			}

			// Token: 0x1700000F RID: 15
			// (get) Token: 0x0600001B RID: 27 RVA: 0x0000365E File Offset: 0x0000185E
			// (set) Token: 0x06000027 RID: 39 RVA: 0x000039B0 File Offset: 0x00001BB0
			public Form7 hcphoarosyelxi
			{
				[DebuggerHidden]
				get
				{
					this.m_Form7 = yupufqwjlhlkfh.jyviwyacpjfptv.rhkqqdrxlawrtf<Form7>(this.m_Form7);
					return this.m_Form7;
				}
				[DebuggerHidden]
				set
				{
					if (value != this.m_Form7)
					{
						if (value != null)
						{
							throw new ArgumentException("Property can only be set to Nothing");
						}
						this.rhkqqdrxlawrtg<Form7>(ref this.m_Form7);
					}
				}
			}

			// Token: 0x17000010 RID: 16
			// (get) Token: 0x0600001C RID: 28 RVA: 0x0000367D File Offset: 0x0000187D
			// (set) Token: 0x06000028 RID: 40 RVA: 0x00003A04 File Offset: 0x00001C04
			public Form8 hcphoarosyelxj
			{
				[DebuggerHidden]
				get
				{
					this.m_Form8 = yupufqwjlhlkfh.jyviwyacpjfptv.rhkqqdrxlawrtf<Form8>(this.m_Form8);
					return this.m_Form8;
				}
				[DebuggerHidden]
				set
				{
					if (value != this.m_Form8)
					{
						if (value != null)
						{
							throw new ArgumentException("Property can only be set to Nothing");
						}
						this.rhkqqdrxlawrtg<Form8>(ref this.m_Form8);
					}
				}
			}

			// Token: 0x17000011 RID: 17
			// (get) Token: 0x0600001D RID: 29 RVA: 0x0000369C File Offset: 0x0000189C
			// (set) Token: 0x06000029 RID: 41 RVA: 0x00003A58 File Offset: 0x00001C58
			public Form9 hcphoarosyelxk
			{
				[DebuggerHidden]
				get
				{
					this.m_Form9 = yupufqwjlhlkfh.jyviwyacpjfptv.rhkqqdrxlawrtf<Form9>(this.m_Form9);
					return this.m_Form9;
				}
				[DebuggerHidden]
				set
				{
					if (value != this.m_Form9)
					{
						if (value != null)
						{
							throw new ArgumentException("Property can only be set to Nothing");
						}
						this.rhkqqdrxlawrtg<Form9>(ref this.m_Form9);
					}
				}
			}

			// Token: 0x04000006 RID: 6
			[ThreadStatic]
			private static Hashtable m_FormBeingCreated;

			// Token: 0x04000007 RID: 7
			[EditorBrowsable(EditorBrowsableState.Never)]
			public Form1 m_Form1;

			// Token: 0x04000008 RID: 8
			[EditorBrowsable(EditorBrowsableState.Never)]
			public Form10 m_Form10;

			// Token: 0x04000009 RID: 9
			[EditorBrowsable(EditorBrowsableState.Never)]
			public Form11 m_Form11;

			// Token: 0x0400000A RID: 10
			[EditorBrowsable(EditorBrowsableState.Never)]
			public Form12 m_Form12;

			// Token: 0x0400000B RID: 11
			[EditorBrowsable(EditorBrowsableState.Never)]
			public Form2 m_Form2;

			// Token: 0x0400000C RID: 12
			[EditorBrowsable(EditorBrowsableState.Never)]
			public Form3 m_Form3;

			// Token: 0x0400000D RID: 13
			[EditorBrowsable(EditorBrowsableState.Never)]
			public Form4 m_Form4;

			// Token: 0x0400000E RID: 14
			[EditorBrowsable(EditorBrowsableState.Never)]
			public Form5 m_Form5;

			// Token: 0x0400000F RID: 15
			[EditorBrowsable(EditorBrowsableState.Never)]
			public Form6 m_Form6;

			// Token: 0x04000010 RID: 16
			[EditorBrowsable(EditorBrowsableState.Never)]
			public Form7 m_Form7;

			// Token: 0x04000011 RID: 17
			[EditorBrowsable(EditorBrowsableState.Never)]
			public Form8 m_Form8;

			// Token: 0x04000012 RID: 18
			[EditorBrowsable(EditorBrowsableState.Never)]
			public Form9 m_Form9;
		}

		// Token: 0x02000006 RID: 6
		[EditorBrowsable(EditorBrowsableState.Never)]
		[MyGroupCollection("System.Web.Services.Protocols.SoapHttpClientProtocol", "Create__Instance__", "Dispose__Instance__", "")]
		internal sealed class jyviwyacpjfptw
		{
			// Token: 0x0600002A RID: 42 RVA: 0x00003AAC File Offset: 0x00001CAC
			[EditorBrowsable(EditorBrowsableState.Never)]
			[DebuggerHidden]
			public override bool Equals(object o)
			{
				bool result;
				for (;;)
				{
					IL_101:
					int num = 62;
					int num2 = 61;
					for (;;)
					{
						num2 ^= 31;
						for (;;)
						{
							IL_66:
							int num3 = Form7.mqgfoefwabbyeu(29);
							int num4 = -4;
							for (;;)
							{
								num4 ^= 19;
								switch (num4 + 20)
								{
								case 0:
								{
									RuntimeMethodHandle runtimeMethodHandle = methodof(yupufqwjlhlkfh.jyviwyacpjfptw.Equals(object)).MethodHandle;
									num4 = Form7.mqgfoefwabbyeu(25);
									continue;
								}
								case 1:
									switch (num3 + 23)
									{
									case 0:
										switch (num2)
										{
										case 31:
											goto IL_B7;
										case 32:
											switch (num)
											{
											case 32:
												result = base.Equals(RuntimeHelpers.GetObjectValue(o));
												num = 60;
												goto IL_0B;
											case 33:
											{
												RuntimeMethodHandle runtimeMethodHandle2 = methodof(yupufqwjlhlkfh.jyviwyacpjfptw..ctor()).MethodHandle;
												num = 63;
												goto IL_0B;
											}
											case 34:
												return result;
											case 35:
												return result;
											}
											goto Block_2;
										case 33:
											goto IL_101;
										case 34:
											break;
										default:
											num3 = -12;
											goto IL_1C;
										}
										IL_0B:
										num ^= 30;
										break;
									case 1:
									{
										RuntimeMethodHandle runtimeMethodHandle3 = methodof(yupufqwjlhlkfh.jyviwyacpjfptw.GetHashCode()).MethodHandle;
										num3 = Form7.mqgfoefwabbyeu(27);
										goto IL_1C;
									}
									case 2:
										break;
									case 3:
										goto IL_B2;
									default:
										num4 = -3;
										continue;
									}
									num2 = 63;
									num3 = -13;
									goto IL_1C;
								case 2:
									goto IL_66;
								case 3:
									goto IL_1C;
								}
								IL_37:
								num4 = Form7.mqgfoefwabbyeu(24);
								continue;
								IL_1C:
								num3 ^= 31;
								goto IL_37;
							}
						}
						IL_B2:
						continue;
						IL_B7:
						RuntimeMethodHandle runtimeMethodHandle4 = methodof(yupufqwjlhlkfh.jyviwyacpjfptw..ctor()).MethodHandle;
						num2 = 0;
						continue;
						Block_2:
						num2 = 62;
					}
				}
				return result;
			}

			// Token: 0x0600002B RID: 43 RVA: 0x00003C28 File Offset: 0x00001E28
			[EditorBrowsable(EditorBrowsableState.Never)]
			[DebuggerHidden]
			public override int GetHashCode()
			{
				int hashCode;
				for (;;)
				{
					IL_C0:
					int num = 8;
					int num2 = 10;
					for (;;)
					{
						num2 ^= 34;
						for (;;)
						{
							IL_42:
							int num3 = 58;
							int num4 = -55;
							for (;;)
							{
								num4 ^= 42;
								switch (num4 + 32)
								{
								case 0:
									goto IL_42;
								case 1:
								{
									RuntimeMethodHandle runtimeMethodHandle = methodof(yupufqwjlhlkfh.jyviwyacpjfptw.GetHashCode()).MethodHandle;
									num4 = Form2.uwpnsrqhswlmjh(30);
									continue;
								}
								case 2:
									switch (num3)
									{
									case 35:
									{
										RuntimeMethodHandle runtimeMethodHandle2 = methodof(yupufqwjlhlkfh.jyviwyacpjfptw.tfattfkwvrahsz(a)).MethodHandle;
										num3 = 61;
										goto IL_1C;
									}
									case 36:
										switch (num2)
										{
										case 37:
											goto IL_C0;
										case 38:
											switch (num)
											{
											case 20:
												return hashCode;
											case 21:
											{
												RuntimeMethodHandle runtimeMethodHandle3 = methodof(yupufqwjlhlkfh.jyviwyacpjfptw.tfattfkwvrahsy()).MethodHandle;
												num = 11;
												goto IL_0B;
											}
											case 22:
												hashCode = base.GetHashCode();
												num = 10;
												goto IL_0B;
											case 23:
												return hashCode;
											}
											goto Block_3;
										case 39:
											goto IL_F2;
										case 40:
											break;
										default:
											num3 = 59;
											goto IL_1C;
										}
										IL_0B:
										num ^= 30;
										break;
									case 37:
										break;
									case 38:
										goto IL_BB;
									default:
										num4 = -54;
										continue;
									}
									num2 = 4;
									num3 = 56;
									goto IL_1C;
								case 3:
									goto IL_1C;
								}
								IL_37:
								num4 = Form2.uwpnsrqhswlmjh(38);
								continue;
								IL_1C:
								num3 ^= 30;
								goto IL_37;
							}
						}
						IL_BB:
						continue;
						Block_3:
						num2 = 7;
						continue;
						IL_F2:
						RuntimeMethodHandle runtimeMethodHandle4 = methodof(yupufqwjlhlkfh.jyviwyacpjfptw.tfattfkwvrahsy()).MethodHandle;
						num2 = 5;
					}
				}
				return hashCode;
			}

			// Token: 0x0600002C RID: 44 RVA: 0x00003D90 File Offset: 0x00001F90
			[EditorBrowsable(EditorBrowsableState.Never)]
			[DebuggerHidden]
			internal Type tfattfkwvrahsy()
			{
				Type typeFromHandle;
				for (;;)
				{
					IL_A8:
					int num = 58;
					int num2 = -3;
					for (;;)
					{
						num2 ^= 30;
						for (;;)
						{
							IL_5B:
							int num3 = Form2.uwpnsrqhswlmjh(47);
							int num4 = -1;
							for (;;)
							{
								num4 ^= 41;
								switch (num4 + 45)
								{
								case 0:
								{
									RuntimeMethodHandle runtimeMethodHandle = methodof(yupufqwjlhlkfh.jyviwyacpjfptw.tfattfkwvrahsy()).MethodHandle;
									num4 = -6;
									continue;
								}
								case 1:
									switch (num3 + 51)
									{
									case 0:
										break;
									case 1:
									{
										RuntimeMethodHandle runtimeMethodHandle2 = methodof(yupufqwjlhlkfh.jyviwyacpjfptw..ctor()).MethodHandle;
										num3 = -32;
										goto IL_19;
									}
									case 2:
										switch (num2 + 32)
										{
										case 0:
											goto IL_A8;
										case 1:
											goto IL_B3;
										case 2:
											switch (num)
											{
											case 37:
												typeFromHandle = typeof(yupufqwjlhlkfh.jyviwyacpjfptw);
												num = 56;
												goto IL_0B;
											case 38:
											{
												RuntimeMethodHandle runtimeMethodHandle3 = methodof(yupufqwjlhlkfh.jyviwyacpjfptw.tfattfkwvrahsy()).MethodHandle;
												num = 57;
												goto IL_0B;
											}
											case 39:
												return typeFromHandle;
											case 40:
												return typeFromHandle;
											}
											goto Block_3;
										case 3:
											break;
										default:
											num3 = -29;
											goto IL_19;
										}
										IL_0B:
										num ^= 31;
										break;
									case 3:
										goto IL_A3;
									default:
										num4 = -4;
										continue;
									}
									num2 = Form2.uwpnsrqhswlmjh(42);
									num3 = -2;
									goto IL_19;
								case 2:
									goto IL_5B;
								case 3:
									goto IL_19;
								}
								IL_34:
								num4 = Form7.mqgfoefwabbyeu(31);
								continue;
								IL_19:
								num3 ^= 46;
								goto IL_34;
							}
						}
						IL_A3:
						continue;
						IL_B3:
						RuntimeMethodHandle runtimeMethodHandle4 = methodof(yupufqwjlhlkfh.jyviwyacpjfptw..ctor()).MethodHandle;
						num2 = -1;
						continue;
						Block_3:
						num2 = Form7.mqgfoefwabbyeu(24);
					}
				}
				return typeFromHandle;
			}

			// Token: 0x0600002D RID: 45 RVA: 0x00003EFC File Offset: 0x000020FC
			[EditorBrowsable(EditorBrowsableState.Never)]
			[DebuggerHidden]
			public override string ToString()
			{
				string result;
				for (;;)
				{
					IL_D9:
					int num = 4;
					int num2 = 31;
					for (;;)
					{
						num2 ^= 52;
						for (;;)
						{
							IL_4E:
							int num3 = 30;
							int num4 = Form7.mqgfoefwabbyeu(32);
							for (;;)
							{
								num4 ^= 39;
								switch (num4 + 51)
								{
								case 0:
									switch (num3)
									{
									case 46:
										break;
									case 47:
										switch (num2)
										{
										case 40:
											goto IL_A5;
										case 41:
											switch (num)
											{
											case 46:
												result = base.ToString();
												num = 5;
												goto IL_0B;
											case 47:
												return result;
											case 48:
											{
												RuntimeMethodHandle runtimeMethodHandle = methodof(yupufqwjlhlkfh.jyviwyacpjfptw.Equals(object)).MethodHandle;
												num = 26;
												goto IL_0B;
											}
											case 49:
												return result;
											}
											goto Block_2;
										case 42:
											goto IL_D9;
										case 43:
											break;
										default:
											num3 = 31;
											goto IL_19;
										}
										IL_0B:
										num ^= 42;
										break;
									case 48:
									{
										RuntimeMethodHandle runtimeMethodHandle2 = methodof(yupufqwjlhlkfh.jyviwyacpjfptw.tfattfkwvrahsz(a)).MethodHandle;
										num3 = 1;
										goto IL_19;
									}
									case 49:
										goto IL_A0;
									default:
										num4 = -23;
										continue;
									}
									num2 = 29;
									num3 = 0;
									goto IL_19;
								case 1:
									goto IL_4E;
								case 2:
								{
									RuntimeMethodHandle runtimeMethodHandle3 = methodof(yupufqwjlhlkfh.jyviwyacpjfptw.Equals(object)).MethodHandle;
									num4 = -24;
									continue;
								}
								case 3:
									goto IL_19;
								}
								IL_34:
								num4 = Form12.wsyoqrrjsoniul(43);
								continue;
								IL_19:
								num3 ^= 49;
								goto IL_34;
							}
						}
						IL_A0:
						continue;
						IL_A5:
						RuntimeMethodHandle runtimeMethodHandle4 = methodof(yupufqwjlhlkfh.jyviwyacpjfptw.tfattfkwvrahsy()).MethodHandle;
						num2 = 28;
						continue;
						Block_2:
						num2 = 30;
					}
				}
				return result;
			}

			// Token: 0x0600002E RID: 46 RVA: 0x0000405C File Offset: 0x0000225C
			[DebuggerHidden]
			private static a tfattfkwvrahsz<a>(a c) where a : new()
			{
				bool flag = c == null;
				a result;
				if (flag)
				{
					result = Activator.CreateInstance<a>();
				}
				else
				{
					result = c;
				}
				return result;
			}

			// Token: 0x0600002F RID: 47 RVA: 0x00004099 File Offset: 0x00002299
			[DebuggerHidden]
			private void tfattfkwvrahta<a>(ref a d)
			{
				d = default(a);
			}

			// Token: 0x06000030 RID: 48 RVA: 0x00002F99 File Offset: 0x00001199
			[DebuggerHidden]
			[EditorBrowsable(EditorBrowsableState.Never)]
			public jyviwyacpjfptw()
			{
			}
		}

		// Token: 0x02000007 RID: 7
		[EditorBrowsable(EditorBrowsableState.Never)]
		[ComVisible(false)]
		internal sealed class jyviwyacpjfptx<a> where a : new()
		{
			// Token: 0x17000012 RID: 18
			// (get) Token: 0x06000031 RID: 49 RVA: 0x000040A8 File Offset: 0x000022A8
			internal a wmopvnnhenfnwr
			{
				[DebuggerHidden]
				get
				{
					bool flag = yupufqwjlhlkfh.jyviwyacpjfptx<a>.m_ThreadStaticValue == null;
					if (flag)
					{
						yupufqwjlhlkfh.jyviwyacpjfptx<a>.m_ThreadStaticValue = Activator.CreateInstance<a>();
					}
					return yupufqwjlhlkfh.jyviwyacpjfptx<a>.m_ThreadStaticValue;
				}
			}

			// Token: 0x06000032 RID: 50 RVA: 0x00002F99 File Offset: 0x00001199
			[DebuggerHidden]
			[EditorBrowsable(EditorBrowsableState.Never)]
			public jyviwyacpjfptx()
			{
			}

			// Token: 0x04000013 RID: 19
			[CompilerGenerated]
			[ThreadStatic]
			private static a m_ThreadStaticValue;
		}
	}
}
