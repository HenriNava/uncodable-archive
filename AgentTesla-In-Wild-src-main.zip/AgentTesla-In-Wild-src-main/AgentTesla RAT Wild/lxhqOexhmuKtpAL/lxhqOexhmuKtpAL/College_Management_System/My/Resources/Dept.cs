using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace College_Management_System.My.Resources
{
	// Token: 0x02000008 RID: 8
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "16.0.0.0")]
	[DebuggerNonUserCode]
	[CompilerGenerated]
	internal class Dept
	{
		// Token: 0x06000033 RID: 51 RVA: 0x00002F99 File Offset: 0x00001199
		internal Dept()
		{
		}

		// Token: 0x17000013 RID: 19
		// (get) Token: 0x06000034 RID: 52 RVA: 0x000040EC File Offset: 0x000022EC
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static ResourceManager agxhxyvtdfojnj
		{
			get
			{
				bool flag = object.ReferenceEquals(Dept.resourceMan, null);
				if (flag)
				{
					for (;;)
					{
						IL_E8:
						int num = Form2.uwpnsrqhswlmjh(50);
						int num2 = -32;
						for (;;)
						{
							num2 ^= 48;
							for (;;)
							{
								IL_86:
								int num3 = 5;
								int num4 = -20;
								for (;;)
								{
									num4 ^= 52;
									switch (num4 + 43)
									{
									case 0:
										switch (num3)
										{
										case 41:
											switch (num2 + 51)
											{
											case 0:
												goto IL_E8;
											case 1:
												switch (num + 43)
												{
												case 0:
												{
													RuntimeMethodHandle runtimeMethodHandle = methodof(Dept..ctor()).MethodHandle;
													num = -28;
													goto IL_2B;
												}
												case 1:
												{
													ResourceManager resourceManager = new ResourceManager("College_Management_System.Dept", typeof(Dept).Assembly);
													num = -26;
													goto IL_2B;
												}
												case 2:
												{
													ResourceManager resourceManager;
													Dept.resourceMan = resourceManager;
													num = Form2.uwpnsrqhswlmjh(45);
													goto IL_2B;
												}
												case 3:
													goto IL_1A7;
												}
												goto Block_4;
											case 2:
												goto IL_120;
											case 3:
												break;
											default:
												num3 = 6;
												goto IL_3E;
											}
											IL_2B:
											num ^= 49;
											break;
										case 42:
											break;
										case 43:
										{
											RuntimeMethodHandle runtimeMethodHandle2 = methodof(Dept.get_agxhxyvtdfojnj()).MethodHandle;
											num3 = 7;
											goto IL_3E;
										}
										case 44:
											goto IL_E3;
										default:
											num4 = -30;
											continue;
										}
										num2 = Form7.mqgfoefwabbyeu(24);
										num3 = 0;
										goto IL_3E;
									case 1:
										goto IL_86;
									case 2:
									{
										RuntimeMethodHandle runtimeMethodHandle3 = methodof(Dept.get_agxhxyvtdfojnj()).MethodHandle;
										num4 = Form12.wsyoqrrjsoniul(52);
										continue;
									}
									case 3:
										goto IL_3E;
									}
									IL_5B:
									num4 = Form2.uwpnsrqhswlmjh(47);
									continue;
									IL_3E:
									num3 ^= 44;
									goto IL_5B;
								}
							}
							IL_E3:
							continue;
							Block_4:
							num2 = Form7.mqgfoefwabbyeu(31);
							continue;
							IL_120:
							RuntimeMethodHandle runtimeMethodHandle4 = methodof(Dept..ctor()).MethodHandle;
							num2 = -1;
						}
					}
					IL_1A7:;
				}
				return Dept.resourceMan;
			}
		}

		// Token: 0x17000014 RID: 20
		// (get) Token: 0x06000035 RID: 53 RVA: 0x000042B4 File Offset: 0x000024B4
		// (set) Token: 0x06000036 RID: 54 RVA: 0x000042CF File Offset: 0x000024CF
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static CultureInfo agxhxyvtdfojnk
		{
			get
			{
				return Dept.resourceCulture;
			}
			set
			{
				Dept.resourceCulture = value;
			}
		}

		// Token: 0x17000015 RID: 21
		// (get) Token: 0x06000037 RID: 55 RVA: 0x000042DC File Offset: 0x000024DC
		internal static Bitmap agxhxyvtdfojnl
		{
			get
			{
				Bitmap result;
				for (;;)
				{
					IL_B5:
					int num = Form7.mqgfoefwabbyeu(29);
					int num2 = Form7.mqgfoefwabbyeu(24);
					for (;;)
					{
						num2 ^= 55;
						for (;;)
						{
							IL_64:
							int num3 = 2;
							int num4 = Form12.wsyoqrrjsoniul(43);
							for (;;)
							{
								num4 ^= 56;
								switch (num4 + 49)
								{
								case 0:
									switch (num3)
									{
									case 49:
										switch (num2 + 58)
										{
										case 0:
											goto IL_B5;
										case 1:
											switch (num + 49)
											{
											case 0:
											{
												object objectValue;
												result = (Bitmap)objectValue;
												num = -11;
												goto IL_0B;
											}
											case 1:
											{
												RuntimeMethodHandle runtimeMethodHandle = methodof(Dept.get_agxhxyvtdfojnj()).MethodHandle;
												num = -9;
												goto IL_0B;
											}
											case 2:
											{
												object objectValue = RuntimeHelpers.GetObjectValue(Dept.agxhxyvtdfojnj.GetObject("SZGeneric", Dept.resourceCulture));
												num = Form12.wsyoqrrjsoniul(41);
												goto IL_0B;
											}
											case 3:
												return result;
											case 4:
												return result;
											}
											goto Block_2;
										case 2:
											goto IL_EF;
										case 3:
											break;
										default:
											num3 = 0;
											goto IL_1C;
										}
										IL_0B:
										num ^= 39;
										break;
									case 50:
									{
										RuntimeMethodHandle runtimeMethodHandle2 = methodof(Dept.get_agxhxyvtdfojnk()).MethodHandle;
										num3 = 1;
										goto IL_1C;
									}
									case 51:
										break;
									case 52:
										goto IL_B0;
									default:
										num4 = -23;
										continue;
									}
									num2 = Form7.mqgfoefwabbyeu(19);
									num3 = 7;
									goto IL_1C;
								case 1:
								{
									RuntimeMethodHandle runtimeMethodHandle3 = methodof(Dept.get_agxhxyvtdfojnl()).MethodHandle;
									num4 = -24;
									continue;
								}
								case 2:
									goto IL_64;
								case 3:
									goto IL_1C;
								}
								IL_39:
								num4 = Form7.mqgfoefwabbyeu(32);
								continue;
								IL_1C:
								num3 ^= 51;
								goto IL_39;
							}
						}
						IL_B0:
						continue;
						Block_2:
						num2 = -15;
						continue;
						IL_EF:
						RuntimeMethodHandle runtimeMethodHandle4 = methodof(Dept.get_agxhxyvtdfojnj()).MethodHandle;
						num2 = -1;
					}
				}
				return result;
			}
		}

		// Token: 0x04000014 RID: 20
		private static ResourceManager resourceMan;

		// Token: 0x04000015 RID: 21
		private static CultureInfo resourceCulture;
	}
}
