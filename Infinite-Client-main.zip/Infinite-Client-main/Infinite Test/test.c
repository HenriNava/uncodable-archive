#include "test.h"

int main(int argc, char** argv)
{
	RtlSecureZeroMemory(&out, sizeof(out));

	if (hDriver = CreateFileA(DEVICE, GENERIC_READ | GENERIC_WRITE, 0, 0, OPEN_EXISTING, 0, 0) == (HANDLE)-1) 
	{
		printf("[-] Failed to obtain handle.");
		unused = getchar();
		return 0;
	}
	printf("[+] Obtained a driver handle.\n[*] Setting up named pipe system...");

	if ((hPipe = CreateNamedPipeW(PIPE, PIPE_ACCESS_DUPLEX | FILE_FLAG_FIRST_PIPE_INSTANCE | FILE_FLAG_WRITE_THROUGH, 0, 1, 1024, 1024, 0, 0) == (HANDLE)-1)) 
	{
		printf("[-] Failed to obtain handle.");
		unused = getchar();
		return 0;
	}
	printf("\n[+] Set up named pipe system.\n[*] Testing named pipe system...");

	DeviceIoControl(hDriver, IOCTL_TEST_NAMED_PIPE, 0, 0, 0, 0, 0, 0);
	Sleep(2000);
	CallNamedPipeW(PIPE, 0, 0, &out, 1024, 1024, NMPWAIT_WAIT_FOREVER);
	printf("\n[+] %s", &out);

	unused = getchar();

	return 1;
}
