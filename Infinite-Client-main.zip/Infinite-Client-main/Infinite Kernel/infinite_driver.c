#include "infinite_driver.h"

NTSTATUS Unload(PDRIVER_OBJECT pDriverObject)
{
	IoDeleteSymbolicLink(&dos);
	IoDeleteDevice(pDriverObject->DeviceObject);
}

NTSTATUS Create(PDEVICE_OBJECT pDeviceObject, PIRP irp)
{
	UNREFERENCED_PARAMETER(pDeviceObject);

	irp->IoStatus.Status = STATUS_SUCCESS;
	irp->IoStatus.Information = 0;

	IoCompleteRequest(irp, IO_NO_INCREMENT);
	return STATUS_SUCCESS;
}

NTSTATUS Close(PDEVICE_OBJECT pDeviceObject, PIRP irp)
{
	UNREFERENCED_PARAMETER(pDeviceObject);

	irp->IoStatus.Status = STATUS_SUCCESS;
	irp->IoStatus.Information = 0;

	IoCompleteRequest(irp, IO_NO_INCREMENT);
	return STATUS_SUCCESS;
}

NTSTATUS DeviceControl(PDEVICE_OBJECT pDeviceObject, PIRP irp)
{
	UNREFERENCED_PARAMETER(pDeviceObject);

	NTSTATUS status = STATUS_INVALID_PARAMETER;
	PIO_STACK_LOCATION io = IoGetCurrentIrpStackLocation(irp);
	HANDLE hPipe = -1;
	OBJECT_ATTRIBUTES objectAttrib;
	IO_STATUS_BLOCK ioStatus;
	InitializeObjectAttributes(&objectAttrib, "\\\\.\\pipe\\infinite", OBJ_KERNEL_HANDLE, 0, 0);
	status = ZwCreateFile(&hPipe, FILE_WRITE_DATA, &objectAttrib, &ioStatus, 0, FILE_ATTRIBUTE_NORMAL, 0, FILE_OPEN, FILE_WRITE_THROUGH, 0, 0);
	DbgPrintEx(DPFLTR_IHVDRIVER_ID, DPFLTR_ERROR_LEVEL, "zwcreatefile status: %d (0x%x)\n", status, status);
	if (status == STATUS_SUCCESS && hPipe != (HANDLE)-1)
	{
		switch (io->Parameters.DeviceIoControl.IoControlCode)
		{
		case IOCTL_TEST_NAMED_PIPE:
		{
			DbgPrintEx(DPFLTR_IHVDRIVER_ID, DPFLTR_ERROR_LEVEL, "allocated kernel mode swimming pool\n");

			status = ZwWriteFile(hPipe, 0, 0, 0, &ioStatus, "test from kernel memory space!", 31, 0, 0);
			ZwClose(hPipe);

			DbgPrintEx(DPFLTR_IHVDRIVER_ID, DPFLTR_ERROR_LEVEL, "write file status: %d (0x%x)\n", status, status);
			break;
		}
		}
	}
	DbgPrintEx(DPFLTR_IHVDRIVER_ID, DPFLTR_ERROR_LEVEL, "end status: %d (0x%x)\n", status, status);

	irp->IoStatus.Status = status;
	irp->IoStatus.Information = 0;
	IoCompleteRequest(irp, IO_NO_INCREMENT);
	return status;
}

NTSTATUS DriverEntry(PDRIVER_OBJECT pDriverObject, PUNICODE_STRING pRegistryPath)
{
	UNREFERENCED_PARAMETER(pRegistryPath);

	RtlInitUnicodeString(&dev, DEVICE);
	RtlInitUnicodeString(&dos, DOS_DEVICE);

	IoCreateDevice(pDriverObject, 0, &dev, FILE_DEVICE_UNKNOWN, FILE_DEVICE_SECURE_OPEN, FALSE, &pDeviceObject);
	IoCreateSymbolicLink(&dos, &dev);

	pDriverObject->MajorFunction[IRP_MJ_CREATE] = Create;
	pDriverObject->MajorFunction[IRP_MJ_CLOSE] = Close;
	pDriverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL] = DeviceControl;
	pDriverObject->DriverUnload = Unload;

	if (pDeviceObject)
	{
		pDeviceObject->Flags |= DO_DIRECT_IO;
		pDeviceObject->Flags &= DO_DEVICE_INITIALIZING;
	}

	return STATUS_SUCCESS;
}
