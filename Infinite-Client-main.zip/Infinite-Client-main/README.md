# Infinite Client
 A hacked client designed for Minecraft Bedrock (Minecraft for Windows 10).

# Note
 This hacked client is a kernel mode cheat. This can cause system instability. Use at own risk.

# Things To Do
 Before I go discovering all the pointers I need to achieve my goal of the first kernel-mode cheat for Minecraft Bedrock, I need to get a method of having the device driver interact with the usermode application. I need to be able to debug what is going on in the driver, and everything I've tried thus far without using WinDbg has failed. Tomorrow or later today, I will be getting the show on the road.
