# Buffer Overflow
 An easy challenge for a stack-based buffer overflow! Preset shellcode will execute calc.exe upon exploitation.

Disable the "Security Check" under Code Generation and compile as a x86 application. This is to make this exploitation scenario actually doable.
