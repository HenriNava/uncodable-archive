using System;

namespace stubPrincipal.xlsgen
{
	// Token: 0x02000023 RID: 35
	internal interface IXlsPivotTableField
	{
		// Token: 0x06001056 RID: 4182
		bool SortAscending();
	}
}
