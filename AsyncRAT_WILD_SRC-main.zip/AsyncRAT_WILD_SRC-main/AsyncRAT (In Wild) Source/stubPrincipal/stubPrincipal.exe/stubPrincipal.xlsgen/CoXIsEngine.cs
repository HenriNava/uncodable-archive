using System;

namespace stubPrincipal.xlsgen
{
	// Token: 0x02000020 RID: 32
	internal class CoXlsEngine
	{
		// Token: 0x0600104B RID: 4171 RVA: 0x00051764 File Offset: 0x0004F964
		internal IXlsWorkbook New(string v)
		{
			throw new NotImplementedException();
		}

		// Token: 0x0600104C RID: 4172 RVA: 0x00051778 File Offset: 0x0004F978
		internal IXlsWorkbook Open(string v1, string v2)
		{
			throw new NotImplementedException();
		}
	}
}
