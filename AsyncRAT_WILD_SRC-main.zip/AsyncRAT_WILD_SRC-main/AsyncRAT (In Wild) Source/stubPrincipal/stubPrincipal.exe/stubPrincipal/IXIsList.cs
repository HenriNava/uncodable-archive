using System;

namespace stubPrincipal
{
	// Token: 0x02000013 RID: 19
	internal interface IXlsList
	{
		// Token: 0x06000D3D RID: 3389
		void Add(string v);

		// Token: 0x06000D3E RID: 3390
		void AddAlternate(string v);

		// Token: 0x06000D3F RID: 3391
		string Name();
	}
}
