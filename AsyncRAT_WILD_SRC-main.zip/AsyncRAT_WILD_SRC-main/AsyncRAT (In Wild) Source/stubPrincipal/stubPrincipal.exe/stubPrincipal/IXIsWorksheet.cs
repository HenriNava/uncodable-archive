using System;

namespace stubPrincipal
{
	// Token: 0x02000018 RID: 24
	internal interface IXlsWorksheet
	{
		// Token: 0x06000D48 RID: 3400
		object NewDynamicRange(string v);

		// Token: 0x06000D49 RID: 3401
		object NewStyle();
	}
}
