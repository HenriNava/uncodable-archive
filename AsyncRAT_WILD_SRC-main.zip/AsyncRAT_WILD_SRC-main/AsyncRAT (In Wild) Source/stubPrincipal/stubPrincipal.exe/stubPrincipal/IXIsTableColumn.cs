using System;

namespace stubPrincipal
{
	// Token: 0x02000015 RID: 21
	internal interface IXlsTableColumn
	{
		// Token: 0x17000677 RID: 1655
		// (get) Token: 0x06000D41 RID: 3393
		// (set) Token: 0x06000D42 RID: 3394
		string Name { get; set; }
	}
}
