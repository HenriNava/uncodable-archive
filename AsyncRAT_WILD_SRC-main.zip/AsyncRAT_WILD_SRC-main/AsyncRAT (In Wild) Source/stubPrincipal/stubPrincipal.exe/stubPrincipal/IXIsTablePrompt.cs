using System;

namespace stubPrincipal
{
	// Token: 0x02000016 RID: 22
	internal interface IXlsTablePrompt
	{
		// Token: 0x06000D43 RID: 3395
		object UniqueValues();

		// Token: 0x06000D44 RID: 3396
		void Apply();
	}
}
