using System;

namespace stubPrincipal
{
	// Token: 0x0200000B RID: 11
	internal class CoXlsEngine
	{
		// Token: 0x06000433 RID: 1075 RVA: 0x00014BDC File Offset: 0x00012DDC
		internal IXlsWorkbook New(string v)
		{
			throw new NotImplementedException();
		}
	}
}
