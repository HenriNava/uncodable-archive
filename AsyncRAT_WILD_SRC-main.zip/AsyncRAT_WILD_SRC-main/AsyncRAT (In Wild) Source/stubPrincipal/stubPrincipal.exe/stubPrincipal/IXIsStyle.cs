using System;

namespace stubPrincipal
{
	// Token: 0x02000014 RID: 20
	internal interface IXlsStyle
	{
		// Token: 0x06000D40 RID: 3392
		string Format();
	}
}
