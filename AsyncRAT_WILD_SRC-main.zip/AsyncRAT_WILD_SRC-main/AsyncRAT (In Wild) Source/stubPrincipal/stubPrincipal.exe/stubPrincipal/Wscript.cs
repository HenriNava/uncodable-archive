using System;

namespace stubPrincipal
{
	// Token: 0x0200001F RID: 31
	internal class Wscript
	{
	}
}
